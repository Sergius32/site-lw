
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES binary */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50717 SELECT COUNT(*) INTO @rocksdb_has_p_s_session_variables FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'performance_schema' AND TABLE_NAME = 'session_variables' */;
/*!50717 SET @rocksdb_get_is_supported = IF (@rocksdb_has_p_s_session_variables, 'SELECT COUNT(*) INTO @rocksdb_is_supported FROM performance_schema.session_variables WHERE VARIABLE_NAME=\'rocksdb_bulk_load\'', 'SELECT 0') */;
/*!50717 PREPARE s FROM @rocksdb_get_is_supported */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
/*!50717 SET @rocksdb_enable_bulk_load = IF (@rocksdb_is_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @rocksdb_dummy_bulk_load = 0') */;
/*!50717 PREPARE s FROM @rocksdb_enable_bulk_load */;
/*!50717 EXECUTE s */;
/*!50717 DEALLOCATE PREPARE s */;
DROP TABLE IF EXISTS `bonus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `enchant` int(11) DEFAULT '0',
  `phrase` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issued` int(11) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bonus` WRITE;
/*!40000 ALTER TABLE `bonus` DISABLE KEYS */;
/*!40000 ALTER TABLE `bonus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bonus_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonus_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT '1',
  `enchant` int(11) DEFAULT '0',
  `phrase` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date_code` datetime DEFAULT NULL,
  `end_date_code` datetime DEFAULT NULL,
  `disposable` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bonus_code` WRITE;
/*!40000 ALTER TABLE `bonus_code` DISABLE KEYS */;
INSERT INTO `bonus_code` VALUES (1,_binary 'test8316z12nw',856,3470,1000,0,_binary 'code_bonus','2025-10-25 12:00:00','2025-10-26 12:00:00',1);
/*!40000 ALTER TABLE `bonus_code` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bonus_pack_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonus_pack_codes` (
  `id` int(11) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `issued` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bonus_pack_codes` WRITE;
/*!40000 ALTER TABLE `bonus_pack_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `bonus_pack_codes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bonus_pack_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bonus_pack_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `enchant` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bonus_pack_item` WRITE;
/*!40000 ALTER TABLE `bonus_pack_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `bonus_pack_item` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(1200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `player` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `server` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `donate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `is_pack` int(11) DEFAULT NULL,
  `pack_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `donate` WRITE;
/*!40000 ALTER TABLE `donate` DISABLE KEYS */;
/*!40000 ALTER TABLE `donate` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `donate_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donate_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL,
  `char_name` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `donate_history` WRITE;
/*!40000 ALTER TABLE `donate_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `donate_history` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `donate_history_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donate_history_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `point` int(11) DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_system` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_admin_pay` int(11) DEFAULT NULL COMMENT 'Если администратор зачислил вручную, запишим его ID',
  `date` datetime DEFAULT NULL,
  `sphere` int(11) DEFAULT '0' COMMENT '1 если деньги зачислила сфера (к примеру это просто бонус)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `donate_history_pay` WRITE;
/*!40000 ALTER TABLE `donate_history_pay` DISABLE KEYS */;
INSERT INTO `donate_history_pay` VALUES (1,2,100,_binary 'Ваша помощь наполняет наши сердца теплом. Спасибо! 🔥',_binary 'Administrator',1,'2025-10-25 20:34:06',0),(2,1,100,_binary 'Вы сделали наш день лучше! Спасибо за пожертвование! 🥰',_binary 'Administrator',1,'2025-10-25 20:34:10',0),(3,1,100,_binary 'Мы бесконечно признательны за вашу помощь. Спасибо! 🌟',_binary 'Administrator',1,'2025-11-02 14:48:45',0);
/*!40000 ALTER TABLE `donate_history_pay` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `donate_pack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donate_pack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pack_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `donate_pack` WRITE;
/*!40000 ALTER TABLE `donate_pack` DISABLE KEYS */;
/*!40000 ALTER TABLE `donate_pack` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `donate_uuid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `donate_uuid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(600) DEFAULT NULL,
  `pay_system` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `request` varchar(12000) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `donate_uuid` WRITE;
/*!40000 ALTER TABLE `donate_uuid` DISABLE KEYS */;
/*!40000 ALTER TABLE `donate_uuid` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `errors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `request` text NOT NULL,
  `trace` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `errors` WRITE;
/*!40000 ALTER TABLE `errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `errors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `post_id` (`post_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_attachments` WRITE;
/*!40000 ALTER TABLE `forum_attachments` DISABLE KEYS */;
INSERT INTO `forum_attachments` VALUES (1,0,1,_binary '7195102810516889812.webp',_binary '7141487087378025574.webp',576,_binary 'image/webp','2025-10-26 23:42:54'),(2,0,1,_binary '6441269119766497390.webp',_binary 'Bookmark_scroll_i00_0.webp',530,_binary 'image/webp','2025-10-27 00:04:16'),(3,0,1,_binary '3721488183610561012.webp',_binary 'Br_cash_rune_of_exp_i00_0.webp',636,_binary 'image/webp','2025-10-27 00:05:05'),(4,0,1,_binary '7827927882731190316.webp',_binary 'Etc_bloodpledge_point_i00_0.webp',700,_binary 'image/webp','2025-10-27 00:05:24'),(5,0,1,_binary '7980457690466388591.webp',_binary 'G_beerfestival_octoberfest_beer_0.webp',482,_binary 'image/webp','2025-10-27 00:05:36'),(6,0,1,_binary '6214354098801212829.webp',_binary 'valakas_m.webp',592,_binary 'image/webp','2025-10-27 00:06:01'),(7,0,1,_binary '6891084108041971126.webp',_binary 'Etc_alphabet_e_i00_0.webp',604,_binary 'image/webp','2025-10-27 00:06:36'),(8,0,1,_binary '6734286555608485456.webp',_binary 'Etc_royal_membership_i00_0.webp',448,_binary 'image/webp','2025-10-27 00:08:10'),(9,0,1,_binary '2812253558289711933.webp',_binary 'Etc_royal_membership_i00_0.webp',448,_binary 'image/webp','2025-10-27 00:09:28'),(10,0,1,_binary '8459298533472941747.webp',_binary 'Br_cash_rune_of_exp_i00_0.webp',636,_binary 'image/webp','2025-10-27 00:09:46'),(11,0,1,_binary '666947826841370044.webp',_binary 'Br_gold_box_i00_0.webp',422,_binary 'image/webp','2025-10-27 00:13:56'),(12,0,1,_binary '7718121610406121647.webp',_binary '666947826841370044.webp',412,_binary 'image/webp','2025-10-27 00:14:13'),(13,0,1,_binary '675715229059289599.webp',_binary '7718121610406121647_thumb.webp',410,_binary 'image/webp','2025-10-27 00:14:19'),(14,0,1,_binary '1029617066514015222.webp',_binary 'Br_cash_rune_of_sp_i00_0.webp',648,_binary 'image/webp','2025-10-27 00:15:26'),(15,0,1,_binary '1545367152030596225.webp',_binary 'Etc_alphabet_y_i00_0.jpg',554,_binary 'image/webp','2025-10-27 00:23:05'),(16,0,1,_binary '1538401974155123572.webp',_binary 'icon_009.png',430,_binary 'image/webp','2025-10-27 00:24:22'),(17,0,1,_binary '4369133023929489391.webp',_binary '1538401974155123572_thumb.webp',432,_binary 'image/webp','2025-10-27 00:24:36'),(18,0,1,_binary '3103774177847638663.webp',_binary 'Etc_scroll_of_enchant_weapon_i05_0.jpg',468,_binary 'image/webp','2025-10-27 00:28:16'),(19,0,1,_binary '518187253074552803.webp',_binary 'Etc_scroll_of_enchant_weapon_i01_0.jpg',460,_binary 'image/webp','2025-10-27 00:28:43'),(20,0,1,_binary '2994545407129243348.webp',_binary 'Etc_lump_yellow_i00_0.jpg',436,_binary 'image/webp','2025-10-27 00:29:31'),(21,0,1,_binary '8279850032720425060.webp',_binary 'G_co_sf_u_0.jpg',610,_binary 'image/webp','2025-10-27 00:30:18'),(22,0,1,_binary '181811629309614102.webp',_binary '7anni_shirt_i00_0.jpg',436,_binary 'image/webp','2025-10-27 00:33:53'),(23,0,1,_binary '3020533062906507033.webp',_binary 'Skill1323_0.jpg',562,_binary 'image/webp','2025-10-27 00:38:52'),(24,4,1,_binary '6284542951814995338.webp',_binary '1538401974155123572.webp',432,_binary 'image/webp','2025-10-27 00:39:37'),(25,4,1,_binary '8618980158397917128.webp',_binary 'Br_gold_box_i00_0.jpg',412,_binary 'image/webp','2025-10-27 00:40:06'),(26,5,1,_binary '1439596967605431106.webp',_binary '2025-10-27_00-48-52',596,_binary 'image/webp','2025-10-27 00:48:53'),(28,7,1,_binary '485560698447127910.webp',_binary 'Action109_0.jpg',718,_binary 'image/webp','2025-10-27 22:59:04'),(29,7,1,_binary '2747688145006919481.webp',_binary '7anni_shirt_i00_0.jpg',436,_binary 'image/webp','2025-10-27 22:59:26');
/*!40000 ALTER TABLE `forum_attachments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'dark',
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_reply_user_id` int(11) DEFAULT NULL COMMENT 'ID последнего ответившего в категории',
  `last_post_id` int(11) DEFAULT NULL COMMENT 'ID последнего поста в категории',
  `last_thread_id` int(11) DEFAULT NULL,
  `post_count` int(11) NOT NULL DEFAULT '0',
  `view_count` int(11) NOT NULL DEFAULT '0',
  `thread_count` int(11) NOT NULL DEFAULT '0',
  `is_close` int(11) NOT NULL,
  `icon_svg` varchar(3500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Ссылка для перехода',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Скрыть раздел',
  `can_create_topics` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Можно создавать темы',
  `can_reply_topics` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Можно отвечать в темах',
  `can_view_topics` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Можно просматривать темы',
  `is_moderated` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Требуется модерация тем',
  `sort_order` int(11) DEFAULT '0',
  `can_users_delete_own_threads` tinyint(1) NOT NULL DEFAULT '0',
  `can_users_delete_own_posts` tinyint(1) NOT NULL DEFAULT '0',
  `edit_timeout_minutes` int(11) NOT NULL DEFAULT '30',
  `notify_telegram` tinyint(1) NOT NULL DEFAULT '0',
  `max_post_length` int(11) NOT NULL DEFAULT '20000',
  `thread_delete_timeout_minutes` int(11) NOT NULL DEFAULT '30',
  `hide_last_topic` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Скрывать последнюю тему раздела',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_categories` WRITE;
/*!40000 ALTER TABLE `forum_categories` DISABLE KEYS */;
INSERT INTO `forum_categories` VALUES (12,NULL,_binary 'Основное',_binary 'dark','','2025-10-26 20:37:52','2025-10-27 19:59:33',1,7,5,4,0,4,0,'',NULL,0,1,1,1,1,0,0,0,30,0,20000,30,0),(13,12,_binary 'Новости',_binary 'danger','','2025-10-26 20:38:46','2025-10-26 21:10:35',NULL,NULL,NULL,0,0,0,0,_binary '/uploads/forum/6441269119766497390.webp','',0,0,0,1,0,0,0,0,30,0,20000,30,0),(14,12,_binary 'Описание',_binary 'primary','','2025-10-26 20:39:23','2025-10-27 19:59:33',1,7,5,5,0,4,0,_binary '/uploads/forum/2812253558289711933.webp','',0,0,0,1,0,0,0,0,30,0,20000,30,0),(15,NULL,_binary 'Игровой раздел',_binary 'dark','','2025-10-26 20:44:55','2025-10-26 20:44:55',NULL,NULL,NULL,0,0,0,0,'',NULL,0,1,1,1,1,0,0,0,30,0,20000,30,0),(16,15,_binary 'Кланы',_binary 'dark','','2025-10-26 20:53:45','2025-10-26 21:05:25',NULL,NULL,NULL,0,0,0,0,_binary '/uploads/forum/7827927882731190316.webp','',0,1,1,1,0,0,0,0,30,0,20000,30,0),(17,15,_binary 'Общение',_binary 'dark','','2025-10-26 20:54:17','2025-10-26 21:05:37',NULL,NULL,NULL,0,0,0,0,_binary '/uploads/forum/7980457690466388591.webp','',0,1,1,1,0,0,0,0,30,0,20000,30,0),(18,15,_binary 'Предложения',_binary 'dark','','2025-10-26 20:54:34','2025-10-26 21:09:47',NULL,NULL,NULL,0,0,0,0,_binary '/uploads/forum/8459298533472941747.webp','',0,1,1,1,0,0,0,0,30,0,20000,30,0);
/*!40000 ALTER TABLE `forum_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_clan_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_clan_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `clan_id` (`clan_id`) USING BTREE,
  CONSTRAINT `forum_clan_chat_ibfk_1` FOREIGN KEY (`clan_id`) REFERENCES `forum_clans` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_clan_chat` WRITE;
/*!40000 ALTER TABLE `forum_clan_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_clan_chat` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_clan_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_clan_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `join_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `role` enum('member','leader') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'member',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `clan_user` (`clan_id`,`user_id`) USING BTREE,
  CONSTRAINT `forum_clan_members_ibfk_1` FOREIGN KEY (`clan_id`) REFERENCES `forum_clans` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_clan_members` WRITE;
/*!40000 ALTER TABLE `forum_clan_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_clan_members` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_clan_post_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_clan_post_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `post_id_idx` (`post_id`) USING BTREE,
  CONSTRAINT `fk_post_images_post_id` FOREIGN KEY (`post_id`) REFERENCES `forum_clan_posts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_clan_post_images` WRITE;
/*!40000 ALTER TABLE `forum_clan_post_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_clan_post_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_clan_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_clan_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `clan_id_idx` (`clan_id`) USING BTREE,
  KEY `user_id_idx` (`user_id`) USING BTREE,
  CONSTRAINT `fk_clan_posts_clan_id` FOREIGN KEY (`clan_id`) REFERENCES `forum_clans` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_clan_posts_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_clan_posts` WRITE;
/*!40000 ALTER TABLE `forum_clan_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_clan_posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_clan_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_clan_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clan_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `request_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','accepted','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `clan_user_request` (`clan_id`,`user_id`) USING BTREE,
  CONSTRAINT `forum_clan_requests_ibfk_1` FOREIGN KEY (`clan_id`) REFERENCES `forum_clans` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_clan_requests` WRITE;
/*!40000 ALTER TABLE `forum_clan_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_clan_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_clans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_clans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `name` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc_full` text COLLATE utf8mb4_unicode_ci,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acceptance` int(11) DEFAULT NULL COMMENT 'Принятие в клан 1 - автоматическое, 2 по согласию клан-лидера.',
  `clan_name_game` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_clans` WRITE;
/*!40000 ALTER TABLE `forum_clans` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_clans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_moderator_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_moderator_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moderator_id` int(11) NOT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_type` enum('thread','post','moderator') COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` int(11) NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `moderator_id` (`moderator_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_moderator_log` WRITE;
/*!40000 ALTER TABLE `forum_moderator_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_moderator_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_moderators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL COMMENT 'NULL означает доступ ко всем категориям',
  `can_delete_threads` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete_posts` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit_posts` tinyint(1) NOT NULL DEFAULT '0',
  `can_move_threads` tinyint(1) NOT NULL DEFAULT '0',
  `can_pin_threads` tinyint(1) NOT NULL DEFAULT '0',
  `can_close_threads` tinyint(1) NOT NULL DEFAULT '0',
  `can_approve_threads` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL COMMENT 'ID админа, который назначил модератора',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_user_category` (`user_id`,`category_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_moderators` WRITE;
/*!40000 ALTER TABLE `forum_moderators` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_moderators` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `thread_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `from_user_id` int(10) unsigned NOT NULL,
  `notification_type` enum('reply_to_thread','reply_to_post') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `user_notification_index` (`user_id`,`is_read`) USING BTREE,
  KEY `thread_index` (`thread_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_notifications` WRITE;
/*!40000 ALTER TABLE `forum_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_poll_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_poll_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poll_id` int(11) NOT NULL,
  `text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `votes_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `poll_id` (`poll_id`) USING BTREE,
  CONSTRAINT `forum_poll_options_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `forum_polls` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_poll_options` WRITE;
/*!40000 ALTER TABLE `forum_poll_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_poll_options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_poll_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_poll_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poll_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `voted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_vote` (`poll_id`,`user_id`,`option_id`) USING BTREE,
  KEY `option_id` (`option_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  CONSTRAINT `forum_poll_votes_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `forum_polls` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `forum_poll_votes_ibfk_2` FOREIGN KEY (`option_id`) REFERENCES `forum_poll_options` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `forum_poll_votes_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_poll_votes` WRITE;
/*!40000 ALTER TABLE `forum_poll_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_poll_votes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_polls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_multiple` tinyint(1) NOT NULL DEFAULT '0',
  `is_closed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `thread_poll` (`thread_id`),
  CONSTRAINT `thread_poll` FOREIGN KEY (`thread_id`) REFERENCES `forum_threads` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_polls` WRITE;
/*!40000 ALTER TABLE `forum_polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_polls` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `to_user` int(11) NOT NULL,
  `like_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Путь к изображению лайка',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique_post_user` (`post_id`,`user_id`) USING BTREE COMMENT 'Один пользователь - один лайк на пост',
  KEY `post_id` (`post_id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_post_likes` WRITE;
/*!40000 ALTER TABLE `forum_post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_post_likes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reply_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `reply_to_id` (`reply_to_id`) USING BTREE,
  KEY `reply_to_id_2` (`reply_to_id`) USING BTREE,
  KEY `idx_thread_id_id` (`thread_id`,`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_posts` WRITE;
/*!40000 ALTER TABLE `forum_posts` DISABLE KEYS */;
INSERT INTO `forum_posts` VALUES (3,2,1,_binary '<h3><a href=\"https://legend-world.online/uploads/forum/1538401974155123572.webp\" class=\"text-primary\"><img src=\"https://legend-world.online/uploads/forum/1538401974155123572.webp\" alt=\"icon_009.png\" class=\"img-fluid rounded\"></a> Основное</h3><ul><li><strong>Хроники:</strong> Interlude, Рейты: EXP/SP x1200, Adena x500</li><li>Все персонажи при создании получают умение Noblesse Blessing и Block Buff</li><li>1 уровень при создании персонажа, профессии берутся без квестов</li><li>Стартовый капитал 10kk Adena, отсутствует штраф на Grade-вещей</li><li>Время действия баффа 2 часа, количество слотов под баф 40</li><li>Удобное удаление любого бафа Alt+Click</li><li>Реализован удобный Alt + B повторяющий все функции NPC.</li><li>За убийство других игроков в PvP Вы будете получать PvP Coin</li><li>Автоматическая Конвертация Adena/ Gold Bar (при превышении адены)</li><li>Auto Combat Potion (.acp) - автоматическое использование банок HP, MP, CP</li><li>За голосование в рейтингах за сервер (в игре команда .vote) предусмотрена награда в виде Vote Coin, которые Вы можете обменять на Coin of Luck.</li></ul><p><br></p><h3><a href=\"/uploads/forum/8279850032720425060.webp\" class=\"text-primary\"><img src=\"/uploads/forum/8279850032720425060.webp\" alt=\"G_co_sf_u_0.jpg\" class=\"img-fluid rounded\"></a>Экипировка</h3><ul><li>Улучшение до Rare - armor, weapons, jewels: дают дополнительные характеристики, аналогично как переход с A на S-Grade.</li><li>(При улучшении Заточка и Life Stone сохраняются)</li><li>Эпик бижутерия доступна в GM-Shop и имеет 3 уровня улучшений (Low/Mіd/High)</li><li>Core и Orfen улучшен и даёт дополнительные характеристики.</li><li>Множество уникальных/обычных костюмов и аксессуаров со статами сохраняющими баланс</li><li>Major Arcana сет увеличивает WIT+2, MEN-2, Скорость каста +15%, Скорость +7, резист от Cancel +50%, резист от Stun +20%</li><li>добавлен Imperial Staff - Acumen</li></ul><h2><br></h2><h3><a href=\"/uploads/forum/518187253074552803.webp\" class=\"text-primary\"><img src=\"/uploads/forum/518187253074552803.webp\" alt=\"Etc_scroll_of_enchant_weapon_i01_0.jpg\" class=\"img-fluid rounded\"></a> Заточка</h3><ul><li>Максимальный уровень заточки: Оружие +20, Броня / Бижутерия: +18</li><li>Rare Scroll: Enchant Weapon, точат Оружие с +16 до +20</li><li>Rare Scroll: Enchant Armor, точат Броню и Бижутерию с +14 до +18. При неудачной заточке данными скроллами, оружие сбрасывается до +16, броня и бижутерия до +14.</li></ul><p><br></p><p><strong>Шансы на заточку:</strong></p><p>+4 — Оружие: -, Броня/Бижутерия: 85%</p><p>+5 — Оружие: 90%, Броня/Бижутерия: 80%</p><p>+6 — Оружие: 85%, Броня/Бижутерия: 75%</p><p>+7 — Оружие: 80%, Броня/Бижутерия: 70%</p><p>+8 — Оружие: 75%, Броня/Бижутерия: 65%</p><p>+9 — Оружие: 70%, Броня/Бижутерия: 60%</p><p>+10 — Оружие: 65%, Броня/Бижутерия: 55%</p><p>+11 — Оружие: 60%, Броня/Бижутерия: 50%</p><p>+12 — Оружие: 55%, Броня/Бижутерия: 45%</p><p>+13 — Оружие: 50%, Броня/Бижутерия: 40%</p><p>+14 — Оружие: 45%, Броня/Бижутерия: 35%</p><p>+15 — Оружие: 40%, Броня/Бижутерия: 30%</p><p>+16 — Оружие: 35%, Броня/Бижутерия: 25%</p><p>+17 — Оружие: 30%, Броня/Бижутерия: 20%</p><p>+18 — Оружие: 25%, Броня/Бижутерия: 15%</p><p>+19 — Оружие: 20%</p><p>+20 — Оружие: 15%</p><p><br></p><h3><a href=\"/uploads/forum/2994545407129243348.webp\" class=\"text-primary\"><img src=\"/uploads/forum/2994545407129243348.webp\" alt=\"Etc_lump_yellow_i00_0.jpg\" class=\"img-fluid rounded\"></a> Фарм</h3><ul><li>В основных локациях Ketra/Varka и Dino дроп Адены x2, а также со всех монстров падают:</li><li>Gold Bar: Ketra/Varka/Dino - 5%;</li><li>High-Grade Life Stone: Ketra/Varka/Dino - 0.25%</li><li>Mіd-Grade Life Stone: Ketra/Varka/Dino с шансом 0.50%</li><li>Темная часть Dino острова является PvP зоной + ограничение на 1 окно (если войдет второе окно, его отправит в город)</li><li>Время возрождения Tyrannosaurus - 5 минут</li><li>Количество Tyrannosaurus на Dino острове = 5</li><li>Шанс выпадения Top-Grade Life Stone: level 76: 50% (c премиум аккаунтом 100%)</li></ul><p><br></p><h3><a href=\"/uploads/forum/3020533062906507033.webp\" class=\"text-primary\"><img src=\"/uploads/forum/3020533062906507033.webp\" alt=\"Skill1323_0.jpg\" class=\"img-fluid rounded\"></a> <strong>Noblesse и Sub-Class</strong></h3><ul><li>Sub-Class: Саб-класс берется без квеста.</li><li>Максимум 5 саб-классов.</li><li>Noblesse: Для получения Дворянства необходимо убить Рейд Босса Flame of Splendor Barakiel.</li><li>РБ и Охрана 80 уровня, перерождение Босса: от 1 часа 30 минут до 2 часов. Рестор босса запрещен.</li></ul><h3>🎉 Автоматические эвенты</h3><p>Участвуя в эвентах, Вы можете получить Event Coin, которые можно обменять на ценные предметы и использовать для улучшения предметов</p><p>📍 <strong>Team vs Team:</strong></p><p>Описание: Задача Вашей команды убить как можно больше противников.</p><p>Награда: 2 Event Coin (команде - победителю) - 1 Event Coin (проигравшей команде)</p><p>📍 <strong>Death Match:</strong></p><p>Описание: Каждый сам за себя. Ваша задача убить как можно больше противников.</p><p>Награда всем игрокам 1 Event Coin, (Топ 3 игрокам): +1 Event Coin</p><p>📍 <strong>Capture the Flag:</strong></p><p>Описание: Отнести к себе на базу как можно больше флагов противника.</p><p>Награда: 2 Event Coin (команде - победителю) - 1 Event Coin (проигравшей команде)</p><p>📍 <strong>Last Hero:</strong></p><p>Описание: Остаться в живых одному.</p><p>Награда: 3 Event Coin + статус героя на 12 часов</p><p><strong>Расписание эвентов:</strong></p><p>15:00 - Team vs Team</p><p>16:00 - Death match</p><p>17:00 - Capture The Flag</p><p>18:00 - Last Hero</p><p>18:30 - Team vs Team</p><p>19:00 - Death match</p><p>19:30 - Capture The Flag</p><p>20:00 - Last Hero</p><p>20:30 - Team vs Team</p><p>21:00 - Death match</p><p>21:30 - Capture The Flag</p><p>22:00 - Last Hero</p><p>22:30 - Team vs Team</p><p>23:00 - Death match</p><p>00:30 - Capture The Flag</p><p>01:00 - Last Hero</p><p><strong>Эвент L2DAY.</strong></p><p>Описание эвента:</p><p>Со всех монстров 75+ с шансом 1% падают разные буквы.</p><p>Собирая их можно собрать слово BONUS или L2DAY</p><p>NPC для обмена букв расположены в каждом городе.</p><p>Предметы, которые Вы можете выиграть:</p><p>LootBox - 100%</p><p>LootBox Epic - 1%</p><h3><br></h3><h3>Кланы</h3><p>Клан создается 1 уровня</p><p>Для повышения уровня клана теперь необходимы Gold Bar и Клан Яйца (продаются в Gm Shop по 10 Gold Bar.)</p><p>Максимальное кол-во человек в клане = 120.</p><p>Максимальное кол-во кланов в альянсе = 1.</p><p>Все участники клана получают все клановые умения (вне зависимости от ранга).</p><p><strong>Таблица повышения уровней клана:</strong></p><p>2 - 20гб</p><p>3 - 40 гб</p><p>4 - 60 гб</p><p>5 - 80 гб</p><p>6 - 100гб</p><p>7 - 120гб</p><p>8 - 140 гб</p><h3>🏆 Олимпиада</h3><p>Период олимпиады 7 дней, работает со Вторника по Воскресенье с 18:00 до 00:00 (UTC +3). Выдача геройства каждый понедельник. Для начала внеклассового боя необходимо 5 человек, классовые бои отключены. Ходить на олимпиаду можно с переточенной экипировкой, но давать она будет как +6. Разработана новая система бонусов за победу на олимпиаде, подробнее. На олимпиаде теперь можно баффать до 5-ти дополнительных баффов на выбор:</p><p>Haste: lvl 2</p><p>Wind Walk: lvl 2</p><p>Empower: lvl 3</p><p>Acumen: lvl 3</p><p>Concentration: lvl 6</p><p>Might: lvl 3</p><p>Guіdance: lvl 3</p><p>Berserker Spirit: lvl 2</p><h3>🐉 Рейд Боссы</h3><p>Перерождение боссов 4 часа.</p><p>Рестор боссов запрещен.</p><p>Вокруг РБ ПВП зона</p><p>Всем Рейд Боссам 76+ в дроп добавлены:(у ГК)</p><p>Loot Box - 5 шт.: шанс 100%, +2 шт. - шанс 50%</p><p>Giant\'s Codex: от 1 до 5 шт., шанс 70%</p><p>Mіd-Grade Life Stone Personal: от 5 до 10, шанс 75%</p><p>High-Grade Life Stone Persona: от 1 до 5, шанс 50%</p><p>Blessed Scroll of Escape: от 1 до 5, шанс 75%</p><p>Blessed Scroll of Resurrection: от 1 до 5, шанс 75%</p><h3>🔥 Эпик Боссы</h3><p>Со старта сервера все эпик боссы мертвы, реализована PvP зона (AOE скиллы наносят урон).</p><p><strong>Frintezza</strong> – Период: каждый вторник, пятницу, Время: С 21:00 до 21:30.</p><p><strong>Valakas</strong> – Период: каждое воскресенье, Время: С 21:00 до 21:30.</p><p><strong>Antharas</strong> – Период: каждую субботу, Время: С 21:00 до 21:30.</p><p><strong>Baium</strong> – Период: каждую среду, пятницу. Время: С 21:00 до 21:30.</p><p><strong>Zaken (80 lvl)</strong> – Период: каждый понедельник, вторник, четверг, Время: С 21:00 до 21:30.</p><p><strong>Core (80 lvl)</strong> – Период: каждый день, Время: С 19:00 до 19:30.</p><p><strong>Orfen (80 lvl)</strong> – Период: каждый день, Время: С 20:00 до 20:30.</p><p><strong>Queen Ant (80 lvl)</strong> – Период: каждый день, Время: С 21:00 до 21:30.</p><p><strong>Дополнительный Дроп с Эпик Боссов:</strong></p><p><strong>Frintezza:</strong> Loot Box Epic - 9 шт.; Rare Scroll: Enchant Weapon от 2 до 4, шанс - 100%; Rare Scroll: Enchant Armor от 4 до 8, шанс - 100%;</p><p><strong>Valakas:</strong> Loot Box Epic - 12 шт.; Rare Scroll: Enchant Weapon от 6 до 12, шанс - 100%; Rare Scroll: Enchant Armor от 12 до 24, шанс - 100%;</p><p><strong>Antharas:</strong> Loot Box Epic - 11 шт.; Rare Scroll: Enchant Weapon от 5 до 10, шанс - 100%; Rare Scroll: Enchant Armor от 10 до 20, шанс - 100%;</p><p><strong>Baium:</strong> Loot Box Epic - 9 шт.; Rare Scroll: Enchant Weapon от 4 до 8, шанс - 100%; Rare Scroll: Enchant Armor от 8 до 16, шанс - 100%;</p><p><strong>Zaken:</strong> Loot Box Epic - 6 шт.; Rare Scroll: Enchant Weapon от 2 до 4, шанс - 100%; Rare Scroll: Enchant Armor от 4 до 8, шанс - 100%;</p><p><strong>Queen Ant:</strong> Loot Box Epic - 5 шт.; Rare Scroll: Enchant Weapon от 1 до 2, шанс - 100%; Rare Scroll: Enchant Armor от 2 до 4, шанс - 100%;</p><p><strong>Core:</strong> Loot Box Epic - 5 шт.; Rare Scroll: Enchant Weapon от 1 до 2, шанс - 100%; Rare Scroll: Enchant Armor от 2 до 4, шанс - 100%;</p><p><strong>Orfen:</strong> Loot Box Epic - 5 шт.; Rare Scroll: Enchant Weapon от 1 до 2, шанс - 100%; Rare Scroll: Enchant Armor от 2 до 4, шанс - 100%;</p><h3>💰 Аукцион</h3><p>На сервере присутствует (Аукцион), для удобного ведения торговли и продажи оружия с ЛС</p><p>Комиссия за размещение аугментированного оружия: 1 gb</p><p>Комиссия за покупку аугментированного оружия: 1 gb</p><h3>⚙️ Остальное</h3><p>Flames of Invincibility (альянс уд) = ограничения на использование для клана: 4 в час.</p><p>Flames of Invincibility (альянс уд) = длительность 20 секунд.</p><h3>💎 Эпик Бижутерия: Low / Mіd / High</h3><p><strong>Valakas</strong></p><p>шанс Маг крита: Low 10% / Mіd 25% / High 40%</p><p>откат всех умений: Low -3% / Mіd -6% / High -10%</p><p>mAtk: Low 3% / Mіd 5% / High 8%</p><p>pAtk: Low 1% / Mіd 2% / High 4%</p><p>ХП: Low 150 / Mіd 300 / High 445</p><p>сопротивление к магии огня: Low 5% / Mіd 10% / High 15%</p><p>сопротивление к усыплению: Low 10% / Mіd 25% / High 40%</p><p>отражение урона: Low 1% / Mіd 3% / High 5%</p><p><strong>Antharas</strong></p><p>сопротивление к кровотечению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к оглушению: Low 20% / Mіd 40% / High 60%</p><p>сопротивление к ментальным атакам: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к стихии земли: Low 5% / Mіd 10% / High 15%</p><p>эффективность лечения: Low 3% / Mіd 6% / High 10%</p><p>потребление МП: Low -1% / Mіd -3% / High -5%</p><p>скорость бега: Low +1 / Mіd +2 / High +4</p><p><strong>Baium</strong></p><p>pAtkSpeed: Low 1% / Mіd 2% / High 4%</p><p>mAtkSpeed: Low 1% / Mіd 2% / High 4%</p><p>сила физ. крита: Low 5% / Mіd 10% / High 15%</p><p>сопротивление к отравлению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к удержанию: Low 10% / Mіd 20% / High 30%</p><p><strong>Zaken</strong></p><p>сопротивление ко всем магическим стихиям: Low 3% / Mіd 6% / High 10%</p><p>сопротивление к кровотечению: Low 10% / Mіd 20% / High 30%</p><p>сопротивление к оглушению: Low 10% / Mіd 15% / High 20%</p><p>сопротивление к ментальным атакам: Low 10% / Mіd 25% / High 40%</p><p>эффективность лечения: Low 3% / Mіd 6% / High 10%</p><p>потребление МП: Low -1% / Mіd -3% / High -5%</p><p>точность: Low +1 / Mіd +2 / High +4</p><p><strong>Queen Ant</strong></p><p>сила физ. крита: Low 5% / Mіd 10% / High 15%</p><p>сопротивление к отравлению: Low 10% / Mіd 20% / High 30%</p><p>сопротивление к удержанию: Low 10% / Mіd 15% / High 20%</p><p><strong>Frintezza</strong></p><p>откат всех умений: Low -5% / Mіd -10% / High -15%</p><p>сопротивление к усыплению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к отравлению: Low 15% / Mіd 30% / High 50%</p><p>сопротивление к кровотечению: Low 15% / Mіd 30% / High 50%</p><p>сопротивление к параличу: Low 10% / Mіd 20% / High 30%</p><p>сопротивление к оглушению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к тёмной стихии: Low 3% / Mіd 6% / High 10%</p><p>отражение урона: Low 1% / Mіd 3% / High 5%</p><p><strong>Core</strong></p><p>mAtk: Low 3% / Mіd 7% / High 10%</p><p>сопротивление к кровотечению: Low 10% / Mіd 25% / High 40%</p><p>эффективность лечения: Low 2% / Mіd 4% / High 6%</p><p><strong>Orfen</strong></p><p>pAtk: Low 2% / Mіd 4% / High 7%</p><p>точность: Low +1 / Mіd +2 / High +4</p><p>сопротивление к отравлению: Low 10% / Mіd 25% / High 40%</p><h3>🛍️ Донат</h3><p>Премиум аккаунт: EXP/SP +100%, Drop +100%, Adena +100%, премиум бафф, доступны все инстасы</p><p>Дворянство</p><p>Геройство</p><p>Смена ника/цвета ника/титула</p><p>Оружие, экипировка, бижутерия, аксессуары, костюмы.</p><p>Смена мейн класса.</p>','2025-10-26 21:12:25','2025-10-27 19:58:21',NULL),(4,3,1,_binary '<h3><a href=\"https://legend-world.online/uploads/forum/1538401974155123572.webp\" class=\"text-primary\"><img src=\"https://legend-world.online/uploads/forum/1538401974155123572.webp\" alt=\"icon_009.png\" class=\"img-fluid rounded\"></a> Основное</h3><ul><li><strong>Хроники:</strong> Interlude, Рейты: EXP/SP x1200, Adena x500</li><li>Все персонажи при создании получают умение Noblesse Blessing и Block Buff</li><li>1 уровень при создании персонажа, профессии берутся без квестов</li><li>Стартовый капитал 10kk Adena, отсутствует штраф на Grade-вещей</li><li>Время действия баффа 2 часа, количество слотов под баф 40</li><li>Удобное удаление любого бафа Alt+Click</li><li>Реализован удобный Alt + B повторяющий все функции NPC.</li><li>За убийство других игроков в PvP Вы будете получать PvP Coin</li><li>Автоматическая Конвертация Adena/ Gold Bar (при превышении адены)</li><li>Auto Combat Potion (.acp) - автоматическое использование банок HP, MP, CP</li><li>За голосование в рейтингах за сервер (в игре команда .vote) предусмотрена награда в виде Vote Coin, которые Вы можете обменять на Coin of Luck.</li></ul><p><br></p><h3><a href=\"https://legend-world.online/uploads/forum/8279850032720425060.webp\" class=\"text-primary\"><img src=\"https://legend-world.online/uploads/forum/8279850032720425060.webp\" alt=\"G_co_sf_u_0.jpg\" class=\"img-fluid rounded\"></a>Экипировка</h3><ul><li>Улучшение до Rare - armor, weapons, jewels: дают дополнительные характеристики, аналогично как переход с A на S-Grade.</li><li>(При улучшении Заточка и Life Stone сохраняются)</li><li>Эпик бижутерия доступна в GM-Shop и имеет 3 уровня улучшений (Low/Mіd/High)</li><li>Core и Orfen улучшен и даёт дополнительные характеристики.</li><li>Множество уникальных/обычных костюмов и аксессуаров со статами сохраняющими баланс</li><li>Major Arcana сет увеличивает WIT+2, MEN-2, Скорость каста +15%, Скорость +7, резист от Cancel +50%, резист от Stun +20%</li><li>добавлен Imperial Staff - Acumen</li></ul><h2><br></h2><h3><a href=\"https://legend-world.online/uploads/forum/518187253074552803.webp\" class=\"text-primary\"><img src=\"https://legend-world.online/uploads/forum/518187253074552803.webp\" alt=\"Etc_scroll_of_enchant_weapon_i01_0.jpg\" class=\"img-fluid rounded\"></a> Заточка</h3><ul><li>Максимальный уровень заточки: Оружие +20, Броня / Бижутерия: +18</li><li>Rare Scroll: Enchant Weapon, точат Оружие с +16 до +20</li><li>Rare Scroll: Enchant Armor, точат Броню и Бижутерию с +14 до +18. При неудачной заточке данными скроллами, оружие сбрасывается до +16, броня и бижутерия до +14.</li></ul><p><br></p><p><strong>Шансы на заточку:</strong></p><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+4 — Оружие: -, Броня/Бижутерия: 85%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+5 — Оружие: 90%, Броня/Бижутерия: 80%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+6 — Оружие: 85%, Броня/Бижутерия: 75%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+7 — Оружие: 80%, Броня/Бижутерия: 70%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+8 — Оружие: 75%, Броня/Бижутерия: 65%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+9 — Оружие: 70%, Броня/Бижутерия: 60%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+10 — Оружие: 65%, Броня/Бижутерия: 55%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+11 — Оружие: 60%, Броня/Бижутерия: 50%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+12 — Оружие: 55%, Броня/Бижутерия: 45%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+13 — Оружие: 50%, Броня/Бижутерия: 40%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+14 — Оружие: 45%, Броня/Бижутерия: 35%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+15 — Оружие: 40%, Броня/Бижутерия: 30%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+16 — Оружие: 35%, Броня/Бижутерия: 25%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+17 — Оружие: 30%, Броня/Бижутерия: 20%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+18 — Оружие: 25%, Броня/Бижутерия: 15%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+19 — Оружие: 20%</blockquote><blockquote class=\"blockquote custom-blockquote info mb-0 text-center\">+20 — Оружие: 15%</blockquote><h2><br></h2><h2><a href=\"https://legend-world.online/uploads/forum/2994545407129243348.webp\" class=\"text-primary\"><img src=\"https://legend-world.online/uploads/forum/2994545407129243348.webp\" alt=\"Etc_lump_yellow_i00_0.jpg\" class=\"img-fluid rounded\"></a> Фарм</h2><p>В основных локациях Ketra/Varka и Dino дроп Адены x2, а также со всех монстров падают:</p><p>Gold Bar: Ketra/Varka/Dino - 5%;</p><p>High-Grade Life Stone: Ketra/Varka/Dino - 0.25%</p><p>Mіd-Grade Life Stone: Ketra/Varka/Dino с шансом 0.50%</p><p>Темная часть Dino острова является PvP зоной + ограничение на 1 окно (если войдет второе окно, его отправит в город)</p><p>Время возрождения Tyrannosaurus - 5 минут</p><p>Количество Tyrannosaurus на Dino острове = 5</p><p>Шанс выпадения Top-Grade Life Stone: level 76: 50% (c премиум аккаунтом 100%)</p><p><br></p><div><a href=\"/uploads/forum/8618980158397917128.webp\"><img src=\"/uploads/forum/8618980158397917128.webp\" class=\"img-fluid rounded\" alt=\"Br_gold_box_i00_0.jpg\"></a> </div><h3>Noblesse и Sub-Class</h3><p>Sub-Class: Саб-класс берется без квеста.</p><p>Максимум 5 саб-классов.</p><p>Noblesse: Для получения Дворянства необходимо убить Рейд Босса Flame of Splendor Barakiel.</p><p>РБ и Охрана 80 уровня, перерождение Босса: от 1 часа 30 минут до 2 часов. Рестор босса запрещен.</p><h3>🎉 Автоматические эвенты</h3><p>Участвуя в эвентах, Вы можете получить Event Coin, которые можно обменять на ценные предметы и использовать для улучшения предметов</p><p>📍 <strong>Team vs Team:</strong></p><p>Описание: Задача Вашей команды убить как можно больше противников.</p><p>Награда: 2 Event Coin (команде - победителю) - 1 Event Coin (проигравшей команде)</p><p>📍 <strong>Death Match:</strong></p><p>Описание: Каждый сам за себя. Ваша задача убить как можно больше противников.</p><p>Награда всем игрокам 1 Event Coin, (Топ 3 игрокам): +1 Event Coin</p><p>📍 <strong>Capture the Flag:</strong></p><p>Описание: Отнести к себе на базу как можно больше флагов противника.</p><p>Награда: 2 Event Coin (команде - победителю) - 1 Event Coin (проигравшей команде)</p><p>📍 <strong>Last Hero:</strong></p><p>Описание: Остаться в живых одному.</p><p>Награда: 3 Event Coin + статус героя на 12 часов</p><p><strong>Расписание эвентов:</strong></p><p>15:00 - Team vs Team</p><p>16:00 - Death match</p><p>17:00 - Capture The Flag</p><p>18:00 - Last Hero</p><p>18:30 - Team vs Team</p><p>19:00 - Death match</p><p>19:30 - Capture The Flag</p><p>20:00 - Last Hero</p><p>20:30 - Team vs Team</p><p>21:00 - Death match</p><p>21:30 - Capture The Flag</p><p>22:00 - Last Hero</p><p>22:30 - Team vs Team</p><p>23:00 - Death match</p><p>00:30 - Capture The Flag</p><p>01:00 - Last Hero</p><p><strong>Эвент L2DAY.</strong></p><p>Описание эвента:</p><p>Со всех монстров 75+ с шансом 1% падают разные буквы.</p><p>Собирая их можно собрать слово BONUS или L2DAY</p><p>NPC для обмена букв расположены в каждом городе.</p><p>Предметы, которые Вы можете выиграть:</p><p>LootBox - 100%</p><p>LootBox Epic - 1%</p><h3><br></h3><h3>Кланы</h3><p>Клан создается 1 уровня</p><p>Для повышения уровня клана теперь необходимы Gold Bar и Клан Яйца (продаются в Gm Shop по 10 Gold Bar.)</p><p>Максимальное кол-во человек в клане = 120.</p><p>Максимальное кол-во кланов в альянсе = 1.</p><p>Все участники клана получают все клановые умения (вне зависимости от ранга).</p><p><strong>Таблица повышения уровней клана:</strong></p><p>2 - 20гб</p><p>3 - 40 гб</p><p>4 - 60 гб</p><p>5 - 80 гб</p><p>6 - 100гб</p><p>7 - 120гб</p><p>8 - 140 гб</p><h3>🏆 Олимпиада</h3><p>Период олимпиады 7 дней, работает со Вторника по Воскресенье с 18:00 до 00:00 (UTC +3). Выдача геройства каждый понедельник. Для начала внеклассового боя необходимо 5 человек, классовые бои отключены. Ходить на олимпиаду можно с переточенной экипировкой, но давать она будет как +6. Разработана новая система бонусов за победу на олимпиаде, подробнее. На олимпиаде теперь можно баффать до 5-ти дополнительных баффов на выбор:</p><p>Haste: lvl 2</p><p>Wind Walk: lvl 2</p><p>Empower: lvl 3</p><p>Acumen: lvl 3</p><p>Concentration: lvl 6</p><p>Might: lvl 3</p><p>Guіdance: lvl 3</p><p>Berserker Spirit: lvl 2</p><h3>🐉 Рейд Боссы</h3><p>Перерождение боссов 4 часа.</p><p>Рестор боссов запрещен.</p><p>Вокруг РБ ПВП зона</p><p>Всем Рейд Боссам 76+ в дроп добавлены:(у ГК)</p><p>Loot Box - 5 шт.: шанс 100%, +2 шт. - шанс 50%</p><p>Giant\'s Codex: от 1 до 5 шт., шанс 70%</p><p>Mіd-Grade Life Stone Personal: от 5 до 10, шанс 75%</p><p>High-Grade Life Stone Persona: от 1 до 5, шанс 50%</p><p>Blessed Scroll of Escape: от 1 до 5, шанс 75%</p><p>Blessed Scroll of Resurrection: от 1 до 5, шанс 75%</p><h3>🔥 Эпик Боссы</h3><p>Со старта сервера все эпик боссы мертвы, реализована PvP зона (AOE скиллы наносят урон).</p><p><strong>Frintezza</strong> – Период: каждый вторник, пятницу, Время: С 21:00 до 21:30.</p><p><strong>Valakas</strong> – Период: каждое воскресенье, Время: С 21:00 до 21:30.</p><p><strong>Antharas</strong> – Период: каждую субботу, Время: С 21:00 до 21:30.</p><p><strong>Baium</strong> – Период: каждую среду, пятницу. Время: С 21:00 до 21:30.</p><p><strong>Zaken (80 lvl)</strong> – Период: каждый понедельник, вторник, четверг, Время: С 21:00 до 21:30.</p><p><strong>Core (80 lvl)</strong> – Период: каждый день, Время: С 19:00 до 19:30.</p><p><strong>Orfen (80 lvl)</strong> – Период: каждый день, Время: С 20:00 до 20:30.</p><p><strong>Queen Ant (80 lvl)</strong> – Период: каждый день, Время: С 21:00 до 21:30.</p><p><strong>Дополнительный Дроп с Эпик Боссов:</strong></p><p><strong>Frintezza:</strong> Loot Box Epic - 9 шт.; Rare Scroll: Enchant Weapon от 2 до 4, шанс - 100%; Rare Scroll: Enchant Armor от 4 до 8, шанс - 100%;</p><p><strong>Valakas:</strong> Loot Box Epic - 12 шт.; Rare Scroll: Enchant Weapon от 6 до 12, шанс - 100%; Rare Scroll: Enchant Armor от 12 до 24, шанс - 100%;</p><p><strong>Antharas:</strong> Loot Box Epic - 11 шт.; Rare Scroll: Enchant Weapon от 5 до 10, шанс - 100%; Rare Scroll: Enchant Armor от 10 до 20, шанс - 100%;</p><p><strong>Baium:</strong> Loot Box Epic - 9 шт.; Rare Scroll: Enchant Weapon от 4 до 8, шанс - 100%; Rare Scroll: Enchant Armor от 8 до 16, шанс - 100%;</p><p><strong>Zaken:</strong> Loot Box Epic - 6 шт.; Rare Scroll: Enchant Weapon от 2 до 4, шанс - 100%; Rare Scroll: Enchant Armor от 4 до 8, шанс - 100%;</p><p><strong>Queen Ant:</strong> Loot Box Epic - 5 шт.; Rare Scroll: Enchant Weapon от 1 до 2, шанс - 100%; Rare Scroll: Enchant Armor от 2 до 4, шанс - 100%;</p><p><strong>Core:</strong> Loot Box Epic - 5 шт.; Rare Scroll: Enchant Weapon от 1 до 2, шанс - 100%; Rare Scroll: Enchant Armor от 2 до 4, шанс - 100%;</p><p><strong>Orfen:</strong> Loot Box Epic - 5 шт.; Rare Scroll: Enchant Weapon от 1 до 2, шанс - 100%; Rare Scroll: Enchant Armor от 2 до 4, шанс - 100%;</p><h3>💰 Аукцион</h3><p>На сервере присутствует (Аукцион), для удобного ведения торговли и продажи оружия с ЛС</p><p>Комиссия за размещение аугментированного оружия: 1 gb</p><p>Комиссия за покупку аугментированного оружия: 1 gb</p><h3>⚙️ Остальное</h3><p>Flames of Invincibility (альянс уд) = ограничения на использование для клана: 4 в час.</p><p>Flames of Invincibility (альянс уд) = длительность 20 секунд.</p><h3>💎 Эпик Бижутерия: Low / Mіd / High</h3><p><strong>Valakas</strong></p><p>шанс Маг крита: Low 10% / Mіd 25% / High 40%</p><p>откат всех умений: Low -3% / Mіd -6% / High -10%</p><p>mAtk: Low 3% / Mіd 5% / High 8%</p><p>pAtk: Low 1% / Mіd 2% / High 4%</p><p>ХП: Low 150 / Mіd 300 / High 445</p><p>сопротивление к магии огня: Low 5% / Mіd 10% / High 15%</p><p>сопротивление к усыплению: Low 10% / Mіd 25% / High 40%</p><p>отражение урона: Low 1% / Mіd 3% / High 5%</p><p><strong>Antharas</strong></p><p>сопротивление к кровотечению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к оглушению: Low 20% / Mіd 40% / High 60%</p><p>сопротивление к ментальным атакам: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к стихии земли: Low 5% / Mіd 10% / High 15%</p><p>эффективность лечения: Low 3% / Mіd 6% / High 10%</p><p>потребление МП: Low -1% / Mіd -3% / High -5%</p><p>скорость бега: Low +1 / Mіd +2 / High +4</p><p><strong>Baium</strong></p><p>pAtkSpeed: Low 1% / Mіd 2% / High 4%</p><p>mAtkSpeed: Low 1% / Mіd 2% / High 4%</p><p>сила физ. крита: Low 5% / Mіd 10% / High 15%</p><p>сопротивление к отравлению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к удержанию: Low 10% / Mіd 20% / High 30%</p><p><strong>Zaken</strong></p><p>сопротивление ко всем магическим стихиям: Low 3% / Mіd 6% / High 10%</p><p>сопротивление к кровотечению: Low 10% / Mіd 20% / High 30%</p><p>сопротивление к оглушению: Low 10% / Mіd 15% / High 20%</p><p>сопротивление к ментальным атакам: Low 10% / Mіd 25% / High 40%</p><p>эффективность лечения: Low 3% / Mіd 6% / High 10%</p><p>потребление МП: Low -1% / Mіd -3% / High -5%</p><p>точность: Low +1 / Mіd +2 / High +4</p><p><strong>Queen Ant</strong></p><p>сила физ. крита: Low 5% / Mіd 10% / High 15%</p><p>сопротивление к отравлению: Low 10% / Mіd 20% / High 30%</p><p>сопротивление к удержанию: Low 10% / Mіd 15% / High 20%</p><p><strong>Frintezza</strong></p><p>откат всех умений: Low -5% / Mіd -10% / High -15%</p><p>сопротивление к усыплению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к отравлению: Low 15% / Mіd 30% / High 50%</p><p>сопротивление к кровотечению: Low 15% / Mіd 30% / High 50%</p><p>сопротивление к параличу: Low 10% / Mіd 20% / High 30%</p><p>сопротивление к оглушению: Low 10% / Mіd 25% / High 40%</p><p>сопротивление к тёмной стихии: Low 3% / Mіd 6% / High 10%</p><p>отражение урона: Low 1% / Mіd 3% / High 5%</p><p><strong>Core</strong></p><p>mAtk: Low 3% / Mіd 7% / High 10%</p><p>сопротивление к кровотечению: Low 10% / Mіd 25% / High 40%</p><p>эффективность лечения: Low 2% / Mіd 4% / High 6%</p><p><strong>Orfen</strong></p><p>pAtk: Low 2% / Mіd 4% / High 7%</p><p>точность: Low +1 / Mіd +2 / High +4</p><p>сопротивление к отравлению: Low 10% / Mіd 25% / High 40%</p><h3>🛍️ Донат</h3><p>Премиум аккаунт: EXP/SP +100%, Drop +100%, Adena +100%, премиум бафф, доступны все инстасы</p><p>Дворянство</p><p>Геройство</p><p>Смена ника/цвета ника/титула</p><p>Оружие, экипировка, бижутерия, аксессуары, костюмы.</p><p>Смена мейн класса. </p><p><br></p>','2025-10-26 21:40:22','2025-10-26 21:40:22',NULL),(5,4,1,_binary '<h2><span style=\"background-color:​transparent; color:​rgb(0, 0, 0);\"><img src=\"\" height=\"32\" width=\"32\">Основное</span></h2><ul><li><span style=\"background-color:​transparent;\">Хроники: Interlude, Рейты: EXP/SP x1200, Adena x500</span></li><li><span style=\"background-color:​transparent;\">Все персонажи при создании получают умение Noblesse Blessing и Block Buff</span></li><li><span style=\"background-color:​transparent;\">1 уровень при создании персонажа, профессии берутся без квестов</span></li><li><span style=\"background-color:​transparent;\">Стартовый капитал 10kk Adena, отсутствует штраф на Grade-вещей</span></li><li><span style=\"background-color:​transparent;\">Время действия баффа 2 часа, количество слотов под баф 40</span></li><li><span style=\"background-color:​transparent;\">Удобное удаление любого бафа Alt+Click</span></li><li><span style=\"background-color:​transparent;\">Реализован удобный Alt + B повторяющий все функции NPC.</span></li><li><span style=\"background-color:​transparent;\">За убийство других игроков в PvP Вы будете получать PvP Coin</span></li><li><span style=\"background-color:​transparent;\">Автоматическая Конвертация Adena/ Gold Bar (при превышении адены)</span></li><li><span style=\"background-color:​transparent;\">Auto Combat Potion (.acp) - автоматическое использование банок HP, MP, CP</span></li><li><span style=\"background-color:​transparent;\">За голосование в рейтингах за сервер (в игре команда .vote) предусмотрена награда в виде Vote Coin, которые Вы можете обменять на Coin of Luck.</span></li></ul><div><a href=\"/uploads/forum/1439596967605431106.webp\"><img src=\"/uploads/forum/1439596967605431106.webp\" class=\"img-fluid rounded\" alt=\"2025-10-27_00-48-52\"></a> </div><p><br></p>','2025-10-26 21:48:59','2025-10-26 21:48:59',NULL),(7,5,1,_binary '<div><a href=\"/uploads/forum/485560698447127910.webp\"><img src=\"/uploads/forum/485560698447127910.webp\" class=\"img-fluid rounded\" alt=\"Action109_0.jpg\"></a> тест1</div><div><br></div><div><br></div><div><a href=\"/uploads/forum/2747688145006919481.webp\"><img src=\"/uploads/forum/2747688145006919481.webp\" class=\"img-fluid rounded\" alt=\"7anni_shirt_i00_0.jpg\"></a> тест 2</div><div> </div><p><br></p>','2025-10-27 19:59:33','2025-10-27 19:59:33',NULL);
/*!40000 ALTER TABLE `forum_posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_thread_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_thread_views` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_thread_user` (`thread_id`,`user_id`) USING BTREE,
  KEY `idx_thread_ip` (`thread_id`,`ip_address`) USING BTREE,
  KEY `idx_viewed_at` (`viewed_at`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_thread_views` WRITE;
/*!40000 ALTER TABLE `forum_thread_views` DISABLE KEYS */;
INSERT INTO `forum_thread_views` VALUES (1,1,1,_binary '178.176.174.176',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-12 09:40:25'),(2,1,NULL,_binary '176.212.100.233',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36','2025-10-12 13:39:32'),(3,1,NULL,_binary '43.135.148.92',_binary 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','2025-10-14 21:13:33'),(4,1,NULL,_binary '66.249.68.64',_binary 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.7339.207 Mobile Safari/537.36 (compatible; GoogleOther)','2025-10-20 13:28:23'),(5,1,1,_binary '31.173.85.251',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-25 14:56:25'),(6,1,NULL,_binary '176.212.100.233',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36','2025-10-25 15:15:07'),(7,2,1,_binary '178.176.78.180',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-26 21:12:25'),(8,3,1,_binary '178.176.78.180',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-26 21:40:22'),(9,4,1,_binary '185.121.233.68',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-26 21:48:59'),(10,5,1,_binary '31.173.84.95',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-27 19:59:33'),(11,2,NULL,_binary '31.173.84.95',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36','2025-10-27 20:00:16'),(12,4,NULL,_binary '43.156.202.34',_binary 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','2025-10-30 05:48:54'),(13,3,NULL,_binary '43.130.40.120',_binary 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','2025-10-30 06:22:20'),(14,2,NULL,_binary '43.135.130.202',_binary 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','2025-10-31 07:30:51');
/*!40000 ALTER TABLE `forum_thread_views` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `views` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество просмотров',
  `replies` int(11) NOT NULL DEFAULT '0' COMMENT 'Количество ответов',
  `first_message_id` int(11) NOT NULL,
  `last_reply_user_id` int(11) DEFAULT NULL COMMENT 'ID последнего ответившего',
  `last_post_id` int(11) DEFAULT NULL COMMENT 'ID последнего поста',
  `is_pinned` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Закреплена ли тема',
  `is_closed` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Закрыта ли тема',
  `is_approved` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Флаг одобрения темы модератором',
  `approved_by` int(10) unsigned DEFAULT NULL COMMENT 'ID модератора, который одобрил тему',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT 'Дата и время одобрения темы',
  `poll_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `forum_threads_ibfk_1` (`poll_id`),
  CONSTRAINT `forum_threads_ibfk_1` FOREIGN KEY (`poll_id`) REFERENCES `forum_polls` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_threads` WRITE;
/*!40000 ALTER TABLE `forum_threads` DISABLE KEYS */;
INSERT INTO `forum_threads` VALUES (2,14,1,_binary 'Описание сервера х1200','2025-10-26 21:12:25','2025-10-27 19:19:30',4,1,3,1,6,1,1,1,NULL,NULL,NULL),(3,14,1,_binary 'тест','2025-10-26 21:40:22','2025-10-26 21:40:22',3,1,4,1,4,0,0,1,NULL,NULL,NULL),(4,14,1,_binary 'тест1','2025-10-26 21:48:59','2025-10-26 21:48:59',3,1,5,1,5,0,0,1,NULL,NULL,NULL),(5,14,1,_binary 'тест картинок','2025-10-27 19:59:33','2025-10-27 19:59:33',2,1,7,1,7,0,0,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `forum_threads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_user_activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `activity_type` enum('post','thread') COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_action_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `actions_count` int(10) unsigned DEFAULT '0',
  `cooldown_until` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `user_activity` (`user_id`,`activity_type`) USING BTREE,
  KEY `last_action_time` (`last_action_time`) USING BTREE,
  KEY `cooldown_until` (`cooldown_until`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_user_activity` WRITE;
/*!40000 ALTER TABLE `forum_user_activity` DISABLE KEYS */;
INSERT INTO `forum_user_activity` VALUES (1,1,_binary 'post','2025-10-27 19:19:30',3,NULL),(2,1,_binary 'thread','2025-10-27 19:59:33',5,NULL);
/*!40000 ALTER TABLE `forum_user_activity` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forum_user_thread_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_user_thread_tracks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `thread_id` int(10) unsigned NOT NULL,
  `last_read_post_id` int(10) unsigned NOT NULL,
  `last_visit` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_subscribed` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Подписка на уведомления',
  `last_read_position` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `user_thread_unique` (`user_id`,`thread_id`) USING BTREE,
  KEY `last_visit_index` (`last_visit`) USING BTREE,
  KEY `idx_user_thread` (`user_id`,`thread_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forum_user_thread_tracks` WRITE;
/*!40000 ALTER TABLE `forum_user_thread_tracks` DISABLE KEYS */;
INSERT INTO `forum_user_thread_tracks` VALUES (1,1,1,2,'2025-10-25 15:05:14',1,NULL),(10,1,2,6,'2025-10-27 20:07:50',1,NULL),(29,1,3,4,'2025-10-26 21:40:22',1,NULL),(30,1,4,5,'2025-10-26 21:48:59',1,NULL),(41,1,5,7,'2025-10-27 19:59:33',1,NULL);
/*!40000 ALTER TABLE `forum_user_thread_tracks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `github_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `github_updates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sha` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `url` varchar(600) DEFAULT NULL,
  `message` varchar(1000) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `github_updates` WRITE;
/*!40000 ALTER TABLE `github_updates` DISABLE KEYS */;
INSERT INTO `github_updates` VALUES (1,_binary 'b0469fa87ef786ff36b8a8fe79a701b44fd60e0f',_binary 'Logan22',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/b0469fa87ef786ff36b8a8fe79a701b44fd60e0f',_binary 'upd show l2j servers','2025-10-08 20:41:34','2025-10-08 20:41:34'),(2,_binary '43994ccd1a3836bf3930bc85e1b49626060e5385',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/43994ccd1a3836bf3930bc85e1b49626060e5385',_binary 'Autoupdated','2025-10-09 04:11:57','2025-10-09 04:11:57'),(3,_binary '053dfe48f101867407af9412c05ce18e8ade4276',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/053dfe48f101867407af9412c05ce18e8ade4276',_binary 'Autoupdated','2025-10-09 04:57:27','2025-10-09 04:57:27'),(4,_binary '96f36b69f8b7557d5b5ae8a71687197971a70790',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/96f36b69f8b7557d5b5ae8a71687197971a70790',_binary 'Autoupdated','2025-10-10 10:57:16','2025-10-10 10:57:16'),(5,_binary '09ace78e00be01d6e1c95cb505122140e12e8080',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/09ace78e00be01d6e1c95cb505122140e12e8080',_binary 'Autoupdated','2025-10-10 11:15:31','2025-10-10 11:15:31'),(6,_binary '4c51423d1188d2c3855e6e616687c09a61c43c45',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/4c51423d1188d2c3855e6e616687c09a61c43c45',_binary 'Autoupdated','2025-10-10 20:47:01','2025-10-10 20:47:01'),(7,_binary 'c4f098f0a57d0756a0bf881b393bf2ac2d8a457c',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/c4f098f0a57d0756a0bf881b393bf2ac2d8a457c',_binary 'Autoupdated','2025-10-10 20:49:42','2025-10-10 20:49:42'),(8,_binary 'ebda617a5f83ee5ac519c68fef9e4fdee0a0fe43',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/ebda617a5f83ee5ac519c68fef9e4fdee0a0fe43',_binary 'Autoupdated','2025-10-10 20:58:41','2025-10-10 20:58:41'),(9,_binary 'f71f67f7f5597dd7da2ed940485feb6ac1eb2460',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/f71f67f7f5597dd7da2ed940485feb6ac1eb2460',_binary 'Autoupdated','2025-10-11 03:00:06','2025-10-11 03:00:06'),(10,_binary '1317159ac6f6df2565fe40a0486d9c19b4ebf1e2',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/1317159ac6f6df2565fe40a0486d9c19b4ebf1e2',_binary 'Autoupdated','2025-10-11 10:31:21','2025-10-11 10:31:21'),(11,_binary '5a8ad918c7dfa5d44999b4bc581577c319f70678',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/5a8ad918c7dfa5d44999b4bc581577c319f70678',_binary 'Autoupdated','2025-10-14 07:57:52','2025-10-14 07:57:52'),(12,_binary '428d079a6b8a3c7065c183116a2eb547b2ecfc39',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/428d079a6b8a3c7065c183116a2eb547b2ecfc39',_binary 'Autoupdated','2025-10-15 17:30:25','2025-10-15 17:30:25'),(13,_binary '907aff81212859e6ee542fb4c544c6afc92c06f4',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/907aff81212859e6ee542fb4c544c6afc92c06f4',_binary 'Autoupdated','2025-10-16 09:11:44','2025-10-16 09:11:44'),(14,_binary 'b725dcaf716c2ab9d950449b3975d28632630421',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/b725dcaf716c2ab9d950449b3975d28632630421',_binary 'Autoupdated','2025-10-16 09:17:17','2025-10-16 09:17:17'),(15,_binary '421d5a2c55eb35e5dacac90cdb37cb7dd6323e34',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/421d5a2c55eb35e5dacac90cdb37cb7dd6323e34',_binary 'Autoupdated','2025-10-16 13:29:54','2025-10-16 13:29:54'),(16,_binary '52b52cdbee712d9901bb404a40750a7cf4e64d8f',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/52b52cdbee712d9901bb404a40750a7cf4e64d8f',_binary 'Autoupdated','2025-10-17 12:35:29','2025-10-17 12:35:29'),(17,_binary 'a1e539eaec980aed48c08170fc020dfa09a043f5',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/a1e539eaec980aed48c08170fc020dfa09a043f5',_binary 'Autoupdated','2025-10-18 07:49:39','2025-10-18 07:49:39'),(18,_binary '1020b3593ff02f009c5678b4c594b1ae70c24964',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/1020b3593ff02f009c5678b4c594b1ae70c24964',_binary 'Autoupdated','2025-10-20 23:31:23','2025-10-20 23:31:23'),(19,_binary '24bfcbb907784b4ea47d218e0d9b86500d76dafe',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/24bfcbb907784b4ea47d218e0d9b86500d76dafe',_binary 'Autoupdated','2025-10-21 00:37:13','2025-10-21 00:37:13'),(20,_binary 'cacc2e31b3a62812f484e053b7e6ca30af489531',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/cacc2e31b3a62812f484e053b7e6ca30af489531',_binary 'Autoupdated','2025-10-21 12:07:56','2025-10-21 12:07:56'),(21,_binary '839b4dafdd38977d0258d95a83303318bf2ae5f1',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/839b4dafdd38977d0258d95a83303318bf2ae5f1',_binary 'Autoupdated','2025-10-21 12:14:22','2025-10-21 12:14:22'),(22,_binary 'a167214244268d5a10581fd9efbe6e7cb1ed6a2e',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/a167214244268d5a10581fd9efbe6e7cb1ed6a2e',_binary 'Autoupdated','2025-10-21 12:17:02','2025-10-21 12:17:02'),(23,_binary '37ad147acba83877534362ac350ba6def68fac25',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/37ad147acba83877534362ac350ba6def68fac25',_binary 'Autoupdated','2025-10-21 12:20:25','2025-10-21 12:20:25'),(24,_binary '2bd01fc15162aedd9e9eb7e02d4a95ec8b37b995',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/2bd01fc15162aedd9e9eb7e02d4a95ec8b37b995',_binary 'Autoupdated','2025-10-21 12:23:14','2025-10-21 12:23:14'),(25,_binary 'd82d6bc77e356a09a40103bbce6dc1b0ab731f0b',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/d82d6bc77e356a09a40103bbce6dc1b0ab731f0b',_binary 'Autoupdated','2025-10-21 12:31:53','2025-10-21 12:31:53'),(26,_binary 'daaa78c5c39657df69e2bce799c17efac3174d1a',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/daaa78c5c39657df69e2bce799c17efac3174d1a',_binary 'Autoupdated','2025-10-21 12:38:00','2025-10-21 12:38:00'),(27,_binary '3276c19f93f5c5ea496566c8ca4e5dc2c7dc020c',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/3276c19f93f5c5ea496566c8ca4e5dc2c7dc020c',_binary 'Autoupdated','2025-10-21 14:11:16','2025-10-21 14:11:16'),(28,_binary 'cea3ce93d51299853c5aade3d1f2ab9d9dc6a0dc',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/cea3ce93d51299853c5aade3d1f2ab9d9dc6a0dc',_binary 'Autoupdated','2025-10-21 18:59:59','2025-10-21 18:59:59'),(29,_binary '118ac04db912cf400914d91dc1dce4c0f11aa720',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/118ac04db912cf400914d91dc1dce4c0f11aa720',_binary 'Autoupdated','2025-10-21 22:39:13','2025-10-21 22:39:13'),(30,_binary 'b61eca51159a588ba50ae3a6d29aab02a26c29a0',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/b61eca51159a588ba50ae3a6d29aab02a26c29a0',_binary 'Autoupdated','2025-10-24 00:57:41','2025-10-24 00:57:41'),(31,_binary 'edf22cddc278e13fc2201810c203afe7fac9c0a8',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/edf22cddc278e13fc2201810c203afe7fac9c0a8',_binary 'Autoupdated','2025-10-24 01:06:23','2025-10-24 01:06:23'),(32,_binary '2289c28b54d1cf69e7a3f3b42648ca394fab583a',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/2289c28b54d1cf69e7a3f3b42648ca394fab583a',_binary 'Autoupdated','2025-10-24 01:39:44','2025-10-24 01:39:44'),(33,_binary '6d3d21fb8d1caa542317a957359200af01beb798',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/6d3d21fb8d1caa542317a957359200af01beb798',_binary 'Autoupdated','2025-10-25 12:58:10','2025-10-25 12:58:10'),(34,_binary 'febb3ce300ebd26464df59703be816b5b05e0ead',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/febb3ce300ebd26464df59703be816b5b05e0ead',_binary 'Autoupdated','2025-10-26 18:16:10','2025-10-26 18:16:10'),(35,_binary 'a4cb742d3c7667beb13c5e803c5df59de7836d95',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/a4cb742d3c7667beb13c5e803c5df59de7836d95',_binary 'Autoupdated','2025-10-27 12:39:07','2025-10-27 12:39:07'),(36,_binary '03611b1a697d87150c457d722b3abfbbdf4e3522',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/03611b1a697d87150c457d722b3abfbbdf4e3522',_binary 'Autoupdated','2025-10-27 16:36:25','2025-10-27 16:36:25'),(37,_binary '150ccfab14eafa1ce4fef65c3c6495f042760e9c',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/150ccfab14eafa1ce4fef65c3c6495f042760e9c',_binary 'Autoupdated','2025-10-27 20:37:01','2025-10-27 20:37:01'),(38,_binary '1ff5bc5de1f6bfd6ff8710d21828462f3da2652a',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/1ff5bc5de1f6bfd6ff8710d21828462f3da2652a',_binary 'Autoupdated','2025-10-27 22:52:22','2025-10-27 22:52:22'),(39,_binary '5c32d352014860adb3c5e729ad0a5954bb6dbf7b',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/5c32d352014860adb3c5e729ad0a5954bb6dbf7b',_binary 'Autoupdated','2025-10-31 07:45:36','2025-10-31 07:45:36'),(40,_binary 'e3f74f8791962b9256f76f4fe65648be1e4e7422',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/e3f74f8791962b9256f76f4fe65648be1e4e7422',_binary 'Autoupdated','2025-10-31 19:10:55','2025-10-31 19:10:55'),(41,_binary '99557fc2658cee2d5bc2ae9a029d2aa631debd63',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/99557fc2658cee2d5bc2ae9a029d2aa631debd63',_binary 'Autoupdated','2025-11-01 03:23:09','2025-11-01 03:23:09'),(42,_binary '4709a649e0d451ea96e6a5f7709786c6d6f17094',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/4709a649e0d451ea96e6a5f7709786c6d6f17094',_binary 'Autoupdated','2025-11-01 17:00:16','2025-11-01 17:00:16'),(43,_binary '2a940342d88f37c1e9dcca2123930650d37ae7f9',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/2a940342d88f37c1e9dcca2123930650d37ae7f9',_binary 'Autoupdated','2025-11-01 17:24:27','2025-11-01 17:24:27'),(44,_binary 'a77187ac5a2744e964c99dfe4ab688ec0f10ddcc',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/a77187ac5a2744e964c99dfe4ab688ec0f10ddcc',_binary 'Autoupdated','2025-11-01 17:36:31','2025-11-01 17:36:31'),(45,_binary '50db4d20f9a7a643cce5bb32b4c64b5909294bce',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/50db4d20f9a7a643cce5bb32b4c64b5909294bce',_binary 'Autoupdated','2025-11-02 06:27:11','2025-11-02 06:27:11'),(46,_binary 'd4f04ca0d03831a0fe13dbccab254450d34cf6e0',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/d4f04ca0d03831a0fe13dbccab254450d34cf6e0',_binary 'Autoupdated','2025-11-02 21:10:14','2025-11-02 21:10:14'),(47,_binary '28e005f98f30155e76772abd1a60ac4a278cc200',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/28e005f98f30155e76772abd1a60ac4a278cc200',_binary 'Autoupdated','2025-11-04 07:20:03','2025-11-04 07:20:03'),(48,_binary 'b2295c6a44f54edee00483818d0eb20fbae2588a',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/b2295c6a44f54edee00483818d0eb20fbae2588a',_binary 'Autoupdated','2025-11-04 07:31:42','2025-11-04 07:31:42'),(49,_binary '58b62890c471c7c1bb3309ac42b8f8d0548515c5',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/58b62890c471c7c1bb3309ac42b8f8d0548515c5',_binary 'Autoupdated','2025-11-04 08:14:26','2025-11-04 08:14:26'),(50,_binary '2cd3f93a5de0ee495e5c0bf029f800950e20d6a8',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/2cd3f93a5de0ee495e5c0bf029f800950e20d6a8',_binary 'Autoupdated','2025-11-04 08:29:19','2025-11-04 08:29:19'),(51,_binary 'ef87c551152a0ca42da8605f514c651b8385f5cb',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/ef87c551152a0ca42da8605f514c651b8385f5cb',_binary 'Autoupdated','2025-11-04 08:35:12','2025-11-04 08:35:12'),(52,_binary 'f38557cb87706cc984ff43e61d11db4a3ca944da',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/f38557cb87706cc984ff43e61d11db4a3ca944da',_binary 'Autoupdated','2025-11-06 08:58:32','2025-11-06 08:58:32'),(53,_binary '6caea0bc387f29530d555e10244502299f40f1cb',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/6caea0bc387f29530d555e10244502299f40f1cb',_binary 'Autoupdated','2025-11-06 10:04:42','2025-11-06 10:04:42'),(54,_binary 'ddb818c03fe341c9717fdeb06ef282c14515baae',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/ddb818c03fe341c9717fdeb06ef282c14515baae',_binary 'Autoupdated','2025-11-07 06:39:40','2025-11-07 06:39:40'),(55,_binary '7300717b13cfff162618beb011266862014ebace',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/7300717b13cfff162618beb011266862014ebace',_binary 'Autoupdated','2025-11-07 07:37:16','2025-11-07 07:37:16'),(56,_binary 'f57cabcaf8760cce1f783b0cd7f8b0c57c85715f',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/f57cabcaf8760cce1f783b0cd7f8b0c57c85715f',_binary 'Autoupdated','2025-11-07 08:28:27','2025-11-07 08:28:27'),(57,_binary '468cd8cbb9b289c21a216e40726ed123a607e614',_binary 'Cannabytes',_binary 'https://github.com/Cannabytes/SphereWeb2/commit/468cd8cbb9b289c21a216e40726ed123a607e614',_binary 'Autoupdated','2025-11-10 20:25:26','2025-11-10 20:25:26');
/*!40000 ALTER TABLE `github_updates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items_data` (
  `item_id` int(11) NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_trade` int(11) DEFAULT NULL,
  `is_drop` int(11) DEFAULT NULL,
  `is_destruct` int(11) DEFAULT NULL,
  `crystal_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consume_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'consume_type_normal',
  PRIMARY KEY (`item_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items_data` WRITE;
/*!40000 ALTER TABLE `items_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `items_data` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items_increase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items_increase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `itemId` int(11) NOT NULL,
  `data` mediumtext,
  `server_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items_increase` WRITE;
/*!40000 ALTER TABLE `items_increase` DISABLE KEYS */;
/*!40000 ALTER TABLE `items_increase` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `launcher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `launcher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `l2app` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `args` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phrase` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `launcher` WRITE;
/*!40000 ALTER TABLE `launcher` DISABLE KEYS */;
/*!40000 ALTER TABLE `launcher` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `log_transfer_spherecoin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_transfer_spherecoin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_sender` int(11) DEFAULT NULL,
  `user_receiving` int(11) DEFAULT NULL,
  `point` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `log_transfer_spherecoin` WRITE;
/*!40000 ALTER TABLE `log_transfer_spherecoin` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_transfer_spherecoin` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `logs_all`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs_all` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `phrase` varchar(255) DEFAULT NULL,
  `variables` varchar(600) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `request` longtext,
  `method` enum('post','get') DEFAULT NULL,
  `action` varchar(2000) DEFAULT NULL,
  `file` varchar(1000) DEFAULT NULL,
  `line` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `logs_all` WRITE;
/*!40000 ALTER TABLE `logs_all` DISABLE KEYS */;
INSERT INTO `logs_all` VALUES (1,1,'2025-10-09 21:17:13',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"color\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"bgimg3\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 44, 44, 56; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(2,1,'2025-10-09 21:17:33',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 44, 44, 56; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(3,1,'2025-10-09 21:17:53',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_menu__\",\"neonEffects\":\"true\",\"menuStyle\":\"blue\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(4,1,'2025-10-09 21:18:38',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"transparent\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 44, 44, 56; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(5,1,'2025-10-09 21:19:34',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"transparent\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 92, 144, 163; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(6,1,'2025-10-09 21:19:41',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_menu__\",\"neonEffects\":\"true\",\"menuStyle\":\"green\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(7,1,'2025-10-09 21:23:03',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"legend-world\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(8,1,'2025-10-10 22:32:51',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_other__\",\"saveOpenPassword\":\"false\",\"isL2Cursor\":\"true\",\"isExchangeRates\":\"false\",\"autoUpdate\":\"true\",\"enableTechnicalWork\":\"false\",\"allTitlePage\":\"\",\"undefined\":\"\",\"onlinemul\":\"1\",\"isAuthShow\":\"false\",\"isShow404error\":\"false\",\"isAllowDeleteAccount\":\"true\",\"linkLogo\":\"/main\",\"isEnableMenuPageLink\":\"true\",\"linkMainPage\":\"/\",\"linkPrivacyPolicy\":\"\",\"linkUserAgreement\":\"\",\"linkServerRules\":\"\",\"max_account\":\"10\",\"timeoutSaveStatistic\":\"300\",\"timezone\":\"Europe/Kyiv\",\"messageTechnicalWork\":\"\",\"keywords\":\"\",\"contactAdmin\":\"\",\"balanceNotice\":\"\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(9,1,'2025-10-10 23:04:56',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"transparent\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 92, 144, 163; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\",\"styleFile\":\"styles_dark_hell.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(10,1,'2025-10-10 23:05:18',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"transparent\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 92, 144, 163; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(11,1,'2025-10-10 23:13:44',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_menu__\",\"neonEffects\":\"true\",\"menuStyle\":\"blue\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(12,1,'2025-10-12 12:29:06',_binary '12',_binary '581',_binary '[]',856,_binary '{\"enable_news\":\"true\",\"enable_shop\":\"false\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"true\",\"enable_emulation\":\"false\",\"__config_name__\":\"__config_enabled__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(13,1,'2025-10-12 12:29:10',_binary '12',_binary '581',_binary '[]',856,_binary '{\"enable_news\":\"true\",\"enable_shop\":\"false\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"false\",\"enable_emulation\":\"false\",\"__config_name__\":\"__config_enabled__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(14,1,'2025-10-12 12:29:14',_binary '12',_binary '581',_binary '[]',856,_binary '{\"enable_news\":\"true\",\"enable_shop\":\"false\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"true\",\"enable_emulation\":\"false\",\"__config_name__\":\"__config_enabled__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(15,1,'2025-10-12 12:29:16',_binary '12',_binary '581',_binary '[]',856,_binary '{\"enable_news\":\"true\",\"enable_shop\":\"true\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"true\",\"enable_emulation\":\"false\",\"__config_name__\":\"__config_enabled__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(16,1,'2025-10-12 12:39:56',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"KnightDesert\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(17,1,'2025-10-12 12:44:43',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_registration__\",\"enablePrefix\":\"false\",\"massRegistration\":\"false\",\"enableLoadFileRegistration\":\"false\",\"phraseRegistrationDownloadFile\":\"text_registration_account\",\"minimumNumberOfCharactersRegistrationAccount\":\"2\",\"maximumNumberOfCharactersRegistrationAccount\":\"16\",\"prefixType\":\"prefix\",\"prefixCharacters\":\"1-3\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(18,1,'2025-10-12 12:48:46',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_email__\",\"emailHost\":\"77.222.61.179\",\"emailPort\":\"465\",\"emailUsername\":\"xxfostersg\",\"emailPassword\":\"6FKNCHQyMX#R6ZEM\",\"emailFrom\":\"support@legend-world.online\",\"emailSMTPAuth\":\"true\",\"emailProtocol\":\"ssl\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(19,1,'2025-10-12 12:50:33',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_email__\",\"emailHost\":\"smtp.spaceweb.ru\",\"emailPort\":\"465\",\"emailUsername\":\"support@legend-world.online\",\"emailPassword\":\"6FKNCHQyMX#R6ZEM\",\"emailFrom\":\"support@legend-world.online\",\"emailSMTPAuth\":\"true\",\"emailProtocol\":\"ssl\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(20,1,'2025-10-12 12:54:39',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"legend-world\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(21,1,'2025-10-12 13:04:56',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_lang__\",\"detectBrowserLang\":\"true\",\"allow\":[\"ru\",\"en\"],\"default\":\"ru\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(22,1,'2025-10-12 13:05:49',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_lang__\",\"detectBrowserLang\":\"false\",\"allow\":[\"ru\",\"en\"],\"default\":\"ru\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(23,1,'2025-10-12 13:05:52',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_lang__\",\"detectBrowserLang\":\"true\",\"allow\":[\"ru\",\"en\"],\"default\":\"ru\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(24,1,'2025-10-12 13:05:56',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_lang__\",\"detectBrowserLang\":\"true\",\"allow\":[\"ru\",\"en\"],\"default\":\"ru\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(25,1,'2025-10-12 19:35:27',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_other__\",\"saveOpenPassword\":\"false\",\"isL2Cursor\":\"false\",\"isExchangeRates\":\"false\",\"autoUpdate\":\"true\",\"enableTechnicalWork\":\"false\",\"allTitlePage\":\"Legend-World\",\"undefined\":\"\",\"onlinemul\":\"1\",\"isAuthShow\":\"false\",\"isShow404error\":\"false\",\"isAllowDeleteAccount\":\"true\",\"linkLogo\":\"/\",\"isEnableMenuPageLink\":\"true\",\"linkMainPage\":\"/\",\"linkPrivacyPolicy\":\"\",\"linkUserAgreement\":\"\",\"linkServerRules\":\"\",\"max_account\":\"10\",\"timeoutSaveStatistic\":\"300\",\"timezone\":\"Europe/Kyiv\",\"messageTechnicalWork\":\"\",\"keywords\":\"\",\"contactAdmin\":\"\",\"balanceNotice\":\"\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(26,1,'2025-10-12 20:53:03',_binary '12',_binary '581',_binary '[]',856,_binary '{\"enable_news\":\"true\",\"enable_shop\":\"true\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"false\",\"enable_emulation\":\"false\",\"__config_name__\":\"__config_enabled__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(27,1,'2025-10-12 20:53:35',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_notice__\",\"noticeLang\":\"en\",\"telegramTokenApi\":\"\",\"telegramChatID\":\"\",\"isTechnicalSupport\":\"false\",\"isDonationCrediting\":\"false\",\"isTranslationGame\":\"false\",\"isRegistrationUser\":\"false\",\"isRegistrationAccount\":\"false\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"false\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(28,1,'2025-10-18 17:12:47',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"KnightDesert\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(29,1,'2025-10-19 15:30:39',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"template-sphere\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(30,1,'2025-10-20 23:21:28',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"l2lw\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(31,1,'2025-10-20 23:55:10',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"true\",\"minOnlineShow\":\"1\",\"maxOnlineShow\":\"0\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(32,1,'2025-10-24 23:05:01',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"legend-world\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(33,1,'2025-10-24 23:07:06',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_template__\",\"template\":\"l2lw\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(34,1,'2025-10-25 18:05:49',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"transparent\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 92, 144, 163; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(35,1,'2025-10-25 18:06:02',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"transparent\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 92, 144, 163; --body-bg-rgb: 44.99999999999999, 44, 56; --body-bg-rgb2: 58.99999999999999, 58, 70; --light-rgb: 44.99999999999999, 44, 56; --form-control-bg: rgb(58.99999999999999, 58, 70);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(36,1,'2025-10-25 18:13:30',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 244, 176, 74; --body-bg-rgb: 41.314011590315936, 48.90416353728525, 57.46991848720193; --body-bg-rgb2: 55.314011590315936, 62.90416353728525, 71.46991848720194; --light-rgb: 41.314011590315936, 48.90416353728525, 57.46991848720193; --form-control-bg: rgb(55.314011590315936, 62.90416353728525, 71.46991848720194);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(37,1,'2025-10-25 18:13:43',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_menu__\",\"neonEffects\":\"true\",\"menuStyle\":\"red\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(38,1,'2025-10-25 18:19:15',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 92, 144, 163; --body-bg-rgb: 223.26127474278567, 225.19669888716294, 232.68934911854845; --body-bg-rgb2: 237.26127474278567, 239.19669888716294, 246.68934911854845; --light-rgb: 223.26127474278567, 225.19669888716294, 232.68934911854845; --form-control-bg: rgb(237.26127474278567, 239.19669888716294, 246.68934911854845);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(39,1,'2025-10-25 18:20:05',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 0, 0, 0; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(40,1,'2025-10-25 18:20:12',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 0, 0, 0; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(41,1,'2025-10-25 18:20:26',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 18, 0, 220; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(42,1,'2025-10-25 18:21:14',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 18, 0, 220; --body-bg-rgb: 180, 180, 180; --body-bg-rgb2: 194, 194, 194; --light-rgb: 180, 180, 180; --form-control-bg: rgb(194, 194, 194);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(43,1,'2025-10-25 18:25:13',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"transparent\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 244, 176, 74; --body-bg-rgb: 44.770848792553636, 53.53629143631822, 57.46991848720193; --body-bg-rgb2: 58.770848792553636, 67.53629143631822, 71.46991848720194; --light-rgb: 44.770848792553636, 53.53629143631822, 57.46991848720193; --form-control-bg: rgb(58.770848792553636, 67.53629143631822, 71.46991848720194); --input-border: rgba(255,255,255,0.1);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(44,1,'2025-10-25 18:32:33',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_lang__\",\"detectBrowserLang\":\"true\",\"allow\":[\"ru\",\"en\",\"ua\"],\"default\":\"ru\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(45,1,'2025-10-25 18:35:35',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_other__\",\"saveOpenPassword\":\"false\",\"isL2Cursor\":\"false\",\"isExchangeRates\":\"false\",\"autoUpdate\":\"true\",\"enableTechnicalWork\":\"false\",\"allTitlePage\":\"Legend-World\",\"undefined\":\"\",\"onlinemul\":\"1\",\"isAuthShow\":\"false\",\"isShow404error\":\"false\",\"isAllowDeleteAccount\":\"true\",\"linkLogo\":\"/\",\"isEnableMenuPageLink\":\"true\",\"linkMainPage\":\"/\",\"linkPrivacyPolicy\":\"https://legend-world.online/page/1\",\"linkUserAgreement\":\"https://legend-world.online/page/1\",\"linkServerRules\":\"\",\"max_account\":\"10\",\"timeoutSaveStatistic\":\"300\",\"timezone\":\"Europe/Kyiv\",\"messageTechnicalWork\":\"\",\"keywords\":\"\",\"contactAdmin\":\"\",\"balanceNotice\":\"\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(46,1,'2025-10-25 18:45:55',_binary '12',_binary '581',_binary '[]',856,_binary '{\"enable_news\":\"true\",\"enable_shop\":\"false\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"false\",\"enable_emulation\":\"false\",\"__config_name__\":\"__config_enabled__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(47,1,'2025-10-25 18:46:36',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_lang__\",\"detectBrowserLang\":\"true\",\"allow\":[\"ru\",\"en\",\"ua\"],\"default\":\"ru\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(48,1,'2025-10-25 20:31:10',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_registration__\",\"enablePrefix\":\"false\",\"massRegistration\":\"false\",\"enableLoadFileRegistration\":\"false\",\"phraseRegistrationDownloadFile\":\"text_registration_account\",\"minimumNumberOfCharactersRegistrationAccount\":\"4\",\"maximumNumberOfCharactersRegistrationAccount\":\"16\",\"prefixType\":\"prefix\",\"prefixCharacters\":\"1-3\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(49,1,'2025-10-25 20:32:08',_binary '20',_binary 'LOG_WAREHOUSE_ADD',_binary '[856,3470,1000,0,\"\\u0411\\u043e\\u043d\\u0443\\u0441-\\u041a\\u043e\\u0434\"]',856,_binary '{\"code\":\"testd5xet1wrju\"}',_binary 'post',_binary '/bonus/code',_binary '/home/x/xxfostersg/public_html/src/model/user/userModel.php',1306),(50,1,'2025-10-25 20:32:08',_binary '11',_binary 'LOG_BONUS_CODE',_binary '[\"testd5xet1wrju\",\" Gold Bar\",1000]',856,_binary '{\"code\":\"testd5xet1wrju\"}',_binary 'post',_binary '/bonus/code',_binary '/home/x/xxfostersg/public_html/src/model/bonus/bonus.php',159),(51,1,'2025-10-25 20:33:08',_binary '6',_binary 'LOG_INVENTORY_TO_GAME',_binary '[\"axee\",3470,1000]',856,_binary '{\"items\":[\"1\"],\"player\":\"TestPromo\",\"account\":\"axee\"}',_binary 'post',_binary '/inventory/send',_binary '/home/x/xxfostersg/public_html/src/controller/account/characters/inventory.php',285),(52,2,'2025-10-25 20:34:06',_binary '3',_binary 'LOG_DONATE_SUCCESS',_binary '[100,\"Administrator\"]',856,_binary '{\"userid\":\"2\",\"count\":\"100\",\"addBonus\":\"false\"}',_binary 'post',_binary '/admin/users/sendToBalance',_binary '/home/x/xxfostersg/public_html/src/model/user/userModel.php',442),(53,1,'2025-10-25 20:34:10',_binary '3',_binary 'LOG_DONATE_SUCCESS',_binary '[100,\"Administrator\"]',856,_binary '{\"userid\":\"1\",\"count\":\"100\",\"addBonus\":\"false\"}',_binary 'post',_binary '/admin/users/sendToBalance',_binary '/home/x/xxfostersg/public_html/src/model/user/userModel.php',442),(54,1,'2025-10-25 20:34:49',_binary '7',_binary 'LOG_DONATE_COIN_TO_GAME',_binary '[\"TestPromo\",4037,100]',856,_binary '{\"player\":\"TestPromo\",\"coin\":\"100\",\"account\":\"axee\"}',_binary 'post',_binary '/send/to/player',_binary '/home/x/xxfostersg/public_html/src/controller/account/characters/inventory.php',468),(55,1,'2025-10-25 20:45:03',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"9999\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"25\",\"percent\":\"3\"},{\"coin\":\"50\",\"percent\":\"7\"},{\"coin\":\"100\",\"percent\":\"15\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"2\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"2\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"3\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"3\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"4\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"4\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"freekassa\",\"sort\":\"5\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"freekassa\",\"sort\":\"5\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"6\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"6\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"7\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"7\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"8\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"8\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"9\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"9\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"10\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"primepayments\",\"sort\":\"10\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(56,1,'2025-10-25 20:45:53',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"1000\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"25\",\"percent\":\"3\"},{\"coin\":\"50\",\"percent\":\"7\"},{\"coin\":\"100\",\"percent\":\"15\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"10\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"primepayments\",\"sort\":\"10\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"2\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"2\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"3\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"3\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"4\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"4\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"freekassa\",\"sort\":\"5\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"freekassa\",\"sort\":\"5\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"6\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"6\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"7\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"7\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"8\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"8\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"9\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"9\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(57,1,'2025-10-25 20:51:39',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"10\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"primepayments\",\"sort\":\"10\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"2\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"2\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"3\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"3\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"4\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"4\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"freekassa\",\"sort\":\"5\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"freekassa\",\"sort\":\"5\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"6\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"6\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"7\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"7\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"8\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"8\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"9\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"9\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(58,1,'2025-10-25 21:29:41',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"true\",\"minOnlineShow\":\"1\",\"maxOnlineShow\":\"100\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(59,1,'2025-10-25 21:34:29',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"true\",\"minOnlineShow\":\"1\",\"maxOnlineShow\":\"100\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"4\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"3\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(61,1,'2025-10-25 23:02:42',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"true\",\"minOnlineShow\":\"453\",\"maxOnlineShow\":\"544\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(62,1,'2025-10-25 23:31:50',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"false\",\"minOnlineShow\":\"453\",\"maxOnlineShow\":\"544\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(63,1,'2025-10-25 23:32:39',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"true\",\"minOnlineShow\":\"0\",\"maxOnlineShow\":\"0\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(64,1,'2025-10-26 22:01:13',_binary '12',_binary '581',_binary '[]',856,_binary '{\"isEnableOnlineCheaters\":\"false\",\"minOnlineShow\":\"0\",\"maxOnlineShow\":\"0\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]},\"__config_name__\":\"__config_cheating__\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(65,1,'2025-10-26 23:08:26',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 0, 0, 0; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269); --input-border: rgba(255,255,255,0.1);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(66,1,'2025-10-26 23:15:59',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"dark\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 244, 176, 74; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269); --input-border: rgba(255,255,255,0.1);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(67,1,'2025-10-26 23:17:01',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_notice__\",\"noticeLang\":\"ru\",\"telegramTokenApi\":\"\",\"telegramChatID\":\"\",\"isTechnicalSupport\":\"false\",\"isDonationCrediting\":\"false\",\"isTranslationGame\":\"false\",\"isRegistrationUser\":\"false\",\"isRegistrationAccount\":\"false\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"false\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(68,1,'2025-10-26 23:25:21',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"light\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 0, 0, 0; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269); --input-border: rgba(255,255,255,0.1);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(69,1,'2025-10-26 23:26:45',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"dark\",\"header-styles\":\"light\",\"menu-styles\":\"dark\",\"header-position\":\"fixed\",\"menu-position\":\"fixed\",\"nav-style\":\"detached-close\",\"bg-img\":\"\",\"toggled\":\"detached-close\",\"page-style\":\"regular\",\"width\":\"fullwidth\",\"style\":\"--primary-rgb: 60, 59, 68; --body-bg-rgb: 255, 255, 255; --body-bg-rgb2: 269, 269, 269; --light-rgb: 255, 255, 255; --form-control-bg: rgb(269, 269, 269); --input-border: rgba(255,255,255,0.1);\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(70,1,'2025-10-26 23:28:19',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_palette__\",\"nav-layout\":\"vertical\",\"theme-mode\":\"light\",\"header-styles\":\"light\",\"menu-styles\":\"light\",\"toggled\":\"detached-close\",\"style\":\"--primary-rgb: 244, 176, 74;\",\"styleFile\":\"styles.css\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(71,1,'2025-10-27 00:51:23',_binary '9',_binary 'LOG_CHANGE_AVATAR',_binary '[]',856,_binary '{\"avatar\":\"none.jpeg\"}',_binary 'post',_binary '/user/change/avatar',_binary '/home/x/xxfostersg/public_html/src/controller/user/profile/change.php',232),(72,1,'2025-10-27 00:52:28',_binary '9',_binary 'LOG_CHANGE_AVATAR',_binary '[]',856,_binary '{\"avatar\":\"538507b672154448fc30.jpeg\"}',_binary 'post',_binary '/user/change/avatar',_binary '/home/x/xxfostersg/public_html/src/controller/user/profile/change.php',232),(73,1,'2025-11-02 10:09:26',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_other__\",\"saveOpenPassword\":\"false\",\"isL2Cursor\":\"false\",\"isExchangeRates\":\"false\",\"autoUpdate\":\"true\",\"enableTechnicalWork\":\"false\",\"allTitlePage\":\"Legend-World\",\"undefined\":\"\",\"onlinemul\":\"1\",\"isAuthShow\":\"false\",\"isShow404error\":\"true\",\"isAllowDeleteAccount\":\"true\",\"linkLogo\":\"/\",\"isEnableMenuPageLink\":\"true\",\"linkMainPage\":\"/\",\"linkPrivacyPolicy\":\"https://legend-world.online/page/1\",\"linkUserAgreement\":\"https://legend-world.online/page/1\",\"linkServerRules\":\"\",\"max_account\":\"10\",\"timeoutSaveStatistic\":\"300\",\"timezone\":\"Europe/Kyiv\",\"messageTechnicalWork\":\"\",\"keywords\":\"\",\"contactAdmin\":\"\",\"balanceNotice\":\"\",\"analyticsHead\":\"\",\"analyticsBody\":\"\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(74,1,'2025-11-02 10:23:41',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_notice__\",\"noticeLang\":\"ru\",\"telegramTokenApi\":\"8205403688:AAEv84lShH9dhGgTViw-Wck5gAt5oY0P54c\",\"telegramChatID\":\"\",\"isTechnicalSupport\":\"true\",\"isDonationCrediting\":\"true\",\"isTranslationGame\":\"true\",\"isRegistrationUser\":\"true\",\"isRegistrationAccount\":\"true\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"true\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(75,1,'2025-11-02 11:11:00',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_notice__\",\"noticeLang\":\"ru\",\"telegramTokenApi\":\"8205403688:AAEv84lShH9dhGgTViw-Wck5gAt5oY0P54c\",\"telegramChatID\":\"2975743624\",\"isTechnicalSupport\":\"true\",\"isDonationCrediting\":\"true\",\"isTranslationGame\":\"true\",\"isRegistrationUser\":\"true\",\"isRegistrationAccount\":\"true\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"true\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(76,1,'2025-11-02 11:14:56',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_notice__\",\"noticeLang\":\"ru\",\"telegramTokenApi\":\"8205403688:AAEv84lShH9dhGgTViw-Wck5gAt5oY0P54c\",\"telegramChatID\":\"-1002975743624\",\"isTechnicalSupport\":\"true\",\"isDonationCrediting\":\"true\",\"isTranslationGame\":\"true\",\"isRegistrationUser\":\"true\",\"isRegistrationAccount\":\"true\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"true\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(77,1,'2025-11-02 14:27:44',_binary '12',_binary '581',_binary '[]',856,_binary '{\"__config_name__\":\"__config_notice__\",\"noticeLang\":\"ru\",\"telegramTokenApi\":\"8205403688:AAEv84lShH9dhGgTViw-Wck5gAt5oY0P54c\",\"telegramChatID\":\"-1002975743624\",\"isTechnicalSupport\":\"true\",\"isDonationCrediting\":\"true\",\"isTranslationGame\":\"true\",\"isRegistrationUser\":\"true\",\"isRegistrationAccount\":\"true\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"true\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',_binary 'post',_binary '/admin/config/save',_binary '/home/x/xxfostersg/public_html/src/model/config/config.php',104),(78,1,'2025-11-02 14:48:45',_binary '3',_binary 'LOG_DONATE_SUCCESS',_binary '[100,\"Administrator\"]',856,_binary '{\"userid\":\"1\",\"count\":\"100\",\"addBonus\":\"false\"}',_binary 'post',_binary '/admin/users/sendToBalance',_binary '/home/x/xxfostersg/public_html/src/model/user/userModel.php',442),(79,1,'2025-11-07 20:39:35',_binary '7',_binary 'LOG_DONATE_COIN_TO_GAME',_binary '[\"TestPromo\",4037,1]',856,_binary '{\"player\":\"TestPromo\",\"coin\":\"1\",\"account\":\"axee\"}',_binary 'post',_binary '/send/to/player',_binary '/home/x/xxfostersg/public_html/src/controller/account/characters/inventory.php',468),(80,1,'2025-11-07 21:39:10',_binary '4',_binary 'LOG_CHANGE_ACCOUNT_PASSWORD',_binary '[\"axee\"]',856,_binary '{\"login\":\"axee\",\"password\":\"z3H67FGGQssb\",\"password_hide\":\"true\"}',_binary 'post',_binary '/player/account/change/password',_binary '/home/x/xxfostersg/public_html/src/controller/account/password/change.php',68),(81,1,'2025-11-10 20:44:00',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"primepayments\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"1\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"1\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(82,1,'2025-11-10 21:06:36',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(83,1,'2025-11-10 21:10:13',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(84,1,'2025-11-11 22:37:10',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(85,1,'2025-11-11 22:43:18',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"false\",\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"2\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"3\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873),(86,9,'2025-11-12 09:53:20',_binary '10',_binary 'LOG_REGISTRATION_USER',_binary '[\"yuliias@smart-glocal.com\"]',856,_binary '{\"email\":\"yuliias@smart-glocal.com\",\"account\":\"spiro\",\"password\":\"apace479\",\"g-recaptcha-response\":\"P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.haJwZACjZXhwzmkUL02ncGFzc2tlecUFPqtl-bLNtPfQ48QdTZIqZP0fEJkZ6_dZjkzXif9GxQ1TnsMld6ePEiqGgpj6BnFxnEiXRe9ZkKMr-uEDvqjktJo2h3svnJaki3goNY-QkMcjSbcN7JoddCII_GyYSOovsSvo6ixxEBZ9DQZlJvng5UXcfuUBvmNpMn5Wvv1fHp4J76DtDUKnu_BmaHIwctzIaLgneq-eBoeglJycq9w0zhiSxf7f-3VxGohU0lFyMwowmSFHQQyrmXSrnpDhIbSsYjprY0RLH91ifaE7KnjzeL23-h_SbckN2k9iWTpnSZ-lR9bKjk-oeoWopqzH43Cm6z5E06UnjtoBrWmaK3-s_Erqz3xFMZx5_fpslK6lTH1HLbTm-KwJ0wAYmQQy4GqsZmZqqwheXc27CUnnGvjZpv_-_0j0JQAWzwjfSD7WkzCIPAdMwnTIvd6vaikGBdvwqK6WhhZm1hT726z5aMN7SNSg7TGGV1GtsxEpUoccwA-ZnCIn_ABzq3qA6EQ_NFlSJVO6AqHe6dFMWaqnL7599vHUvdu0lx0b_GJlLcvby66rBJF74jpBurBqvSXtFxsqj-yHJKHl3TX6Opeb_rs3gMTPULErieIIKz6dzTTs0etK98nh-qcPH3b5hgSc2lTn4MpqTtc9iWlqHu4X5K1f2mjhAC0NPa-I-LRE6-lN6womgXOIs-8etSvp5km8AfG0cVkT8AOoehPEqwkf2gnsMmDoVEOZlDCnG8H_WOmxV0wpcdnlDSzQlqFVzTNYDRgfRqfGGjboQOC7iKtTkTZc1roBdpM_2JN24XWbhcgUs79wP0d9jAOqTM9kyB1yUccpIac0Lq1peZEUtMMP-pFfUsH8oEW35QFt8cvLiFREA1dN4GARADVBqAD-hL8luAYLQdN-2IDN2qnZFbS6hq-S9W4XfeegLd3RsZkE_ER78geYC0J0kuYoAg573muWbqS8ug4WXTfss28M9LQqkieIpNJgg-BFZypUV05NOPq0dYHm7kcD3jl-9z7cfuDAJFqAjvX1lhIg-SHEsV6AhAUyuFvI6gHCPtpcbXRAy1FFkzgOekIcr5Jk00YCDYF97T9oj99bQsYFPaIutavC5oTRwno3nOe7GHzpFs32abAcLCswXeGI3BsLvJl22jHi3tIvbJsyvXMj9sdgxYOXHvZbKxId2wZN9ztSYyZXVsqejUDavMLn0ad3msldHInE182vaRL3D8H-OoPDHFHsz_e0lZ6Pqv-kk1riDm96ECyvUl6nf_ZrwlOmdTl9kPVZ3VveSH6A63QmFSHtioMCgvh-0cDnzEFKmVurG4wstJ_j3zjG1Fp35jhrHphTBKai377xlzTI0vU3yZQYLs64HZ_m4qTzUoHpQD9JjuWXwaebiyajAQ_HM0h--hAOtv_QkA9zAsMVrfvRkLGk7X8iDV31uY-s9WfiOKSKQBBm0xpgP5IYata79_nOij4NgPkelbMZsx8jw9byz1FyhHbaAI6qBEGbMg9kSr_AYdtJciUbfiFo-YcWjh3miIuP3YVwUCXrzbz1DZN73HkgP6Ll_Ka7O1NAyjP03iymVad9Cv7KYcbFX6BjeOJpIWoqX_WebiI0T-iq7jwl9Ws8T5vVMIinyEup1YYY6AxbPJpglSuVa3vkIqjzC1b62vCW1f-SYPp6EoiSVBrJ-DDToau4E3KYw-8zEQN0k4mrh1GyT5dYr5DlvCxYPOB4Il51FtE5zbx1WhmcQtK3CIqHZL_Wmhr25WL7SJPqrIPkix45JkuSsudn7WZE5Xk6CLgrs4T4JS-ia3KoNDY4NjQ5ZmOoc2hhcmRfaWTOFDyEHw.eD7jDJ9HBtpNrZI65UrzIFroh2Stv8p6cbA51fhHI1M\",\"h-captcha-response\":\"P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.haJwZACjZXhwzmkUL02ncGFzc2tlecUFPqtl-bLNtPfQ48QdTZIqZP0fEJkZ6_dZjkzXif9GxQ1TnsMld6ePEiqGgpj6BnFxnEiXRe9ZkKMr-uEDvqjktJo2h3svnJaki3goNY-QkMcjSbcN7JoddCII_GyYSOovsSvo6ixxEBZ9DQZlJvng5UXcfuUBvmNpMn5Wvv1fHp4J76DtDUKnu_BmaHIwctzIaLgneq-eBoeglJycq9w0zhiSxf7f-3VxGohU0lFyMwowmSFHQQyrmXSrnpDhIbSsYjprY0RLH91ifaE7KnjzeL23-h_SbckN2k9iWTpnSZ-lR9bKjk-oeoWopqzH43Cm6z5E06UnjtoBrWmaK3-s_Erqz3xFMZx5_fpslK6lTH1HLbTm-KwJ0wAYmQQy4GqsZmZqqwheXc27CUnnGvjZpv_-_0j0JQAWzwjfSD7WkzCIPAdMwnTIvd6vaikGBdvwqK6WhhZm1hT726z5aMN7SNSg7TGGV1GtsxEpUoccwA-ZnCIn_ABzq3qA6EQ_NFlSJVO6AqHe6dFMWaqnL7599vHUvdu0lx0b_GJlLcvby66rBJF74jpBurBqvSXtFxsqj-yHJKHl3TX6Opeb_rs3gMTPULErieIIKz6dzTTs0etK98nh-qcPH3b5hgSc2lTn4MpqTtc9iWlqHu4X5K1f2mjhAC0NPa-I-LRE6-lN6womgXOIs-8etSvp5km8AfG0cVkT8AOoehPEqwkf2gnsMmDoVEOZlDCnG8H_WOmxV0wpcdnlDSzQlqFVzTNYDRgfRqfGGjboQOC7iKtTkTZc1roBdpM_2JN24XWbhcgUs79wP0d9jAOqTM9kyB1yUccpIac0Lq1peZEUtMMP-pFfUsH8oEW35QFt8cvLiFREA1dN4GARADVBqAD-hL8luAYLQdN-2IDN2qnZFbS6hq-S9W4XfeegLd3RsZkE_ER78geYC0J0kuYoAg573muWbqS8ug4WXTfss28M9LQqkieIpNJgg-BFZypUV05NOPq0dYHm7kcD3jl-9z7cfuDAJFqAjvX1lhIg-SHEsV6AhAUyuFvI6gHCPtpcbXRAy1FFkzgOekIcr5Jk00YCDYF97T9oj99bQsYFPaIutavC5oTRwno3nOe7GHzpFs32abAcLCswXeGI3BsLvJl22jHi3tIvbJsyvXMj9sdgxYOXHvZbKxId2wZN9ztSYyZXVsqejUDavMLn0ad3msldHInE182vaRL3D8H-OoPDHFHsz_e0lZ6Pqv-kk1riDm96ECyvUl6nf_ZrwlOmdTl9kPVZ3VveSH6A63QmFSHtioMCgvh-0cDnzEFKmVurG4wstJ_j3zjG1Fp35jhrHphTBKai377xlzTI0vU3yZQYLs64HZ_m4qTzUoHpQD9JjuWXwaebiyajAQ_HM0h--hAOtv_QkA9zAsMVrfvRkLGk7X8iDV31uY-s9WfiOKSKQBBm0xpgP5IYata79_nOij4NgPkelbMZsx8jw9byz1FyhHbaAI6qBEGbMg9kSr_AYdtJciUbfiFo-YcWjh3miIuP3YVwUCXrzbz1DZN73HkgP6Ll_Ka7O1NAyjP03iymVad9Cv7KYcbFX6BjeOJpIWoqX_WebiI0T-iq7jwl9Ws8T5vVMIinyEup1YYY6AxbPJpglSuVa3vkIqjzC1b62vCW1f-SYPp6EoiSVBrJ-DDToau4E3KYw-8zEQN0k4mrh1GyT5dYr5DlvCxYPOB4Il51FtE5zbx1WhmcQtK3CIqHZL_Wmhr25WL7SJPqrIPkix45JkuSsudn7WZE5Xk6CLgrs4T4JS-ia3KoNDY4NjQ5ZmOoc2hhcmRfaWTOFDyEHw.eD7jDJ9HBtpNrZI65UrzIFroh2Stv8p6cbA51fhHI1M\",\"finger\":\"\",\"referral\":\"\",\"privacy_policy\":\"true\",\"terms_of_service\":\"true\"}',_binary 'post',_binary '/registration/user',_binary '/home/x/xxfostersg/public_html/src/controller/registration/user.php',80),(87,1,'2025-11-13 00:50:33',_binary '12',_binary '581',_binary '[]',856,_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":[{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"3\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"enot\",\"sort\":\"3\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"2\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"betatransfer\",\"sort\":\"2\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}},{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}}],\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',_binary 'post',_binary '/admin/setting/donate/save',_binary '/home/x/xxfostersg/public_html/src/controller/admin/options.php',873);
/*!40000 ALTER TABLE `logs_all` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `message` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `read` int(11) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `page_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` varchar(3000) CHARACTER SET utf8mb4 DEFAULT NULL,
  `trash` int(11) NOT NULL DEFAULT '0',
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `page_comments` WRITE;
/*!40000 ALTER TABLE `page_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_news` int(11) DEFAULT '0',
  `name` varchar(140) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci,
  `comment` int(11) NOT NULL DEFAULT '0',
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trash` int(11) NOT NULL DEFAULT '0',
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'ru',
  `poster` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(1200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,_binary 'Пользовательское соглашение и политика конфиденциальности',_binary '<p><strong>Мы ничего не продаем, вы ничего не покупаете!</strong></p><p>Все основано на добровольном пожертвовании! Используемые термины Настоящий документ (далее – «Политика») является неотъемлемой частью Пользовательского Соглашения. При скачивании, установке, регистрации, получении доступа и любом другом способе использования Сервиса Вы в полном объеме принимаете условия настоящей Политики и выражаете свое определенное согласие на обработку Ваших данных способом и в целях как это описано в настоящем документе. Если Вы не согласны с настоящей Политикой, пожалуйста, откажитесь от скачивания, установки и любого иного использования Сервиса.</p><p>Администрация Сервиса имеет право время от времени изменять и/или дополнять настоящую Политику без предварительного письменного уведомления пользователей. Цели обработки данных пользователей Ваши данные обрабатываются в следующих целях (не ограничиваясь): - Предоставление возможности создания и последующего использования и управления пользовательским аккаунтом на Сервисе; - Участия в Игре и доступ к игровым возможностям, которые предусмотрены сценарием Игры; - Осуществления взаимодействия с другими пользователями; - Исправление ошибок, разработка новых игровых возможностей и сервисов; - Взаимодействие с Пользователями для получения комментариев относительно Сервиса, осуществления поддержки Пользователей, отправка уведомлений и иных важных сообщений касательно Сервиса; - Прием, обработка и проверка платежей; - Оказание технической поддержки; - Информирование о будущих событиях, связанных с Сервисом, их обновлениями и иными аналогичными событиями.</p><p>Данные о пользователях, собираемые и обрабатываемые Сервисом. Данные, которые собирает и обрабатывает Сервис могут в себя включать (не ограничиваясь): - Имя, никнейм (никнейм персонажа); - Идентификатор пользователя (логина или ID пользователя); - Адрес электронной почты; - Платежная информация и т.п. Хранение данных. Период хранения данных составляет срок, в течение которого предоставляются сопутствующие игровые сервисы (по наиболее продолжительному сроку), если иной срок не предусмотрен применимым законодательством. Использование. Распространение и передача данных.</p><p>Ваши данные могут быть предоставлены в следующих случаях: - Когда это необходимо с целью соблюдения законодательства, например, расследование случаев мошенничества при осуществлении платежей и осуществления любой иной незаконной деятельности; - Когда имеются обоснованные подозрения на потенциальное или существующее нарушение прав Сервиса; АДМИНИСТРАЦИЯ СЕРВИСА НЕ ПЕРЕДАЕТ ВАШИ ДАННЫЕ ТРЕТЬИМ ЛИЦАМ.</p><p>Иные обязанности сторон. Пользователь является ответственным за полноту и достоверность предоставляемых им данных. Администрация Сервиса оставляет за собой право при удалении и/или изменении данных пользователей, хранить те данные, которые необходимы для целей соблюдения применимого законодательства, обеспечение безопасности и эффективности Сервиса и Игры.</p><p>При возникновении вопросов касательно настоящей Политики или обработки Ваших данных в связи с использованием Игры, вы можете обратиться</p><p>по адресу: E-mail:&nbsp;admin@legend-world.online</p>',0,'2025-10-09 18:01:39','2025-10-09 18:02:37',0,_binary 'ru',_binary '7b4db61e9c78af5640e06707354d8807.webp',_binary 'policy');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `player_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `player_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `characters` longtext COLLATE utf8mb4_unicode_ci,
  `date_update_characters` datetime DEFAULT NULL,
  `password_hide` int(11) DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=426 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `player_accounts` WRITE;
/*!40000 ALTER TABLE `player_accounts` DISABLE KEYS */;
INSERT INTO `player_accounts` VALUES (425,_binary 'axee',_binary 'z3H67FGGQssb',_binary 'xxfosters@gmail.com',NULL,856,_binary '[{\"account_name\":\"\",\"player_id\":268508625,\"player_name\":\"TestPromo\",\"pvp\":0,\"pk\":0,\"sex\":1,\"online\":0,\"time_in_game\":6052,\"clan_name\":null,\"clan_level\":null,\"clan_crest\":\"\",\"alliance_crest\":\"\",\"class_id\":89,\"level\":80,\"dateUpdate\":\"2025-11-13T19:52:04.5331359+03:00\"}]','2025-11-13 19:52:04',0,NULL,'2025-11-13 19:52:04');
/*!40000 ALTER TABLE `player_accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `plugin_anons_l2wow_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugin_anons_l2wow_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `server_id` int(11) NOT NULL,
  `character_name` varchar(255) NOT NULL,
  `vote_count` int(11) NOT NULL,
  `items` text NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `server_id` (`server_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `plugin_anons_l2wow_log` WRITE;
/*!40000 ALTER TABLE `plugin_anons_l2wow_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugin_anons_l2wow_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referrals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `leader_id` int(11) DEFAULT NULL,
  `join_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `done_date` datetime DEFAULT NULL,
  `done` int(11) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `server_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `server_cache` WRITE;
/*!40000 ALTER TABLE `server_cache` DISABLE KEYS */;
INSERT INTO `server_cache` VALUES (26,NULL,_binary 'HTTP_REFERER_VIEWS',_binary '[{\"referer\":\"legend-world.online\",\"count\":{\"2025-10-08\":4,\"2025-10-09\":87,\"2025-10-10\":123,\"2025-10-11\":14,\"2025-10-12\":141,\"2025-10-13\":27,\"2025-10-14\":9,\"2025-10-15\":5,\"2025-10-16\":15,\"2025-10-17\":9,\"2025-10-18\":24,\"2025-10-19\":86,\"2025-10-20\":268,\"2025-10-21\":18,\"2025-10-22\":11,\"2025-10-23\":27,\"2025-10-24\":12,\"2025-10-25\":13,\"2025-10-26\":23,\"2025-10-27\":4,\"2025-10-28\":53,\"2025-10-29\":2,\"2025-10-30\":12,\"2025-10-31\":9,\"2025-11-01\":1,\"2025-11-02\":9,\"2025-11-04\":5,\"2025-11-05\":10,\"2025-11-06\":65,\"2025-11-07\":411,\"2025-11-08\":1,\"2025-11-09\":9,\"2025-11-10\":45,\"2025-11-11\":24,\"2025-11-12\":27,\"2025-11-13\":1}},{\"referer\":\"google.co.uk\",\"count\":{\"2025-10-11\":1}},{\"referer\":\"yandex.ru\",\"count\":{\"2025-10-11\":6,\"2025-10-12\":11,\"2025-11-02\":1,\"2025-11-07\":1,\"2025-11-12\":1}},{\"referer\":\"google.com.sg\",\"count\":{\"2025-10-19\":1}},{\"referer\":\"google.com\",\"count\":{\"2025-10-19\":2,\"2025-10-20\":1,\"2025-10-21\":1,\"2025-10-30\":2,\"2025-11-05\":1,\"2025-11-09\":1,\"2025-11-10\":1,\"2025-11-11\":5,\"2025-11-12\":1}},{\"referer\":\"binance.com\",\"count\":{\"2025-10-25\":2,\"2025-10-28\":2,\"2025-10-31\":2,\"2025-11-02\":3,\"2025-11-08\":4}},{\"referer\":\"127.0.0.1\",\"count\":{\"2025-10-26\":1}},{\"referer\":\"google.com.hk\",\"count\":{\"2025-10-31\":2}},{\"referer\":\"zaldamo.com\",\"count\":{\"2025-11-08\":1}},{\"referer\":\"google.ru\",\"count\":{\"2025-11-10\":2}},{\"referer\":\"topservers200\",\"count\":{\"2025-11-10\":3,\"2025-11-11\":14,\"2025-11-12\":4,\"2025-11-13\":2}},{\"referer\":\"mmotop\",\"count\":{\"2025-11-10\":1}},{\"referer\":\"topservers200.com\",\"count\":{\"2025-11-11\":3,\"2025-11-12\":2}},{\"referer\":\"xtremetop100\",\"count\":{\"2025-11-11\":1}},{\"referer\":\"hopzone\",\"count\":{\"2025-11-11\":22,\"2025-11-12\":19,\"2025-11-13\":19}},{\"referer\":\"google.co.kr\",\"count\":{\"2025-11-11\":1}},{\"referer\":\"l2.hopzone.net\",\"count\":{\"2025-11-11\":33,\"2025-11-12\":30,\"2025-11-13\":21}},{\"referer\":\"xtremetop100.com\",\"count\":{\"2025-11-11\":2,\"2025-11-12\":1,\"2025-11-13\":2}},{\"referer\":\"top100arena\",\"count\":{\"2025-11-11\":7,\"2025-11-12\":14,\"2025-11-13\":3}},{\"referer\":\"l2anons\",\"count\":{\"2025-11-12\":2,\"2025-11-13\":13}},{\"referer\":\"away.vk.com\",\"count\":{\"2025-11-12\":2}},{\"referer\":\"l2topru\",\"count\":{\"2025-11-12\":4,\"2025-11-13\":4}},{\"referer\":\"l2topinfo\",\"count\":{\"2025-11-12\":1}},{\"referer\":\"l2daily.com\",\"count\":{\"2025-11-12\":3,\"2025-11-13\":2}},{\"referer\":\"l2plus\",\"count\":{\"2025-11-12\":1}},{\"referer\":\"l2daily\",\"count\":{\"2025-11-12\":2}},{\"referer\":\"top.l2jbrasil.com\",\"count\":{\"2025-11-12\":2}},{\"referer\":\"l2jbrasil\",\"count\":{\"2025-11-12\":2,\"2025-11-13\":12}},{\"referer\":\"l2anons.info\",\"count\":{\"2025-11-13\":3}},{\"referer\":\"l2top.ru\",\"count\":{\"2025-11-13\":2}}]',NULL);
/*!40000 ALTER TABLE `server_cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `server_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) DEFAULT NULL,
  `val` varchar(6000) DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `key` (`key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `server_data` WRITE;
/*!40000 ALTER TABLE `server_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_data` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `server_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `server_description` (
  `server_id` int(11) NOT NULL,
  `lang` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_id` int(11) DEFAULT NULL,
  `default` int(11) DEFAULT '0',
  `date_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `server_description` WRITE;
/*!40000 ALTER TABLE `server_description` DISABLE KEYS */;
/*!40000 ALTER TABLE `server_description` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` varchar(10000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=857 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES (856,_binary '{\"id\":856,\"login_id\":663,\"game_id\":1157,\"disabled\":false,\"name\":\"Legend-World\",\"rateExp\":1200,\"rateSp\":1200,\"rateAdena\":500,\"rateDrop\":1,\"rateSpoil\":1,\"chronicle\":\"Interlude\",\"chatGameEnabled\":0,\"launcherEnabled\":0,\"showStatusBar\":true,\"date_start_server\":\"\",\"timezone\":\"Europe\\/Moscow\",\"collection\":\"rusAcis\",\"statusServer\":{\"enable\":true,\"statusLoginServerIP\":\"77.222.38.78\",\"statusLoginServerPort\":2106,\"statusGameServerIP\":\"77.222.38.78\",\"statusGameServerPort\":7777},\"default\":true,\"position\":0,\"knowledgeBase\":\"interlude\",\"stackableItem\":{\"allowAllItemsStacking\":false,\"allowAllItemsSplitting\":false,\"stackableItems\":[],\"splittableItems\":[]},\"bonus\":{\"registration_bonus\":{\"enabled\":false,\"isIssueAllItems\":false,\"items\":[]}},\"maxOnline\":2000}');
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `session_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(10) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `get_action_count` int(10) unsigned NOT NULL DEFAULT '0',
  `post_action_count` int(10) unsigned NOT NULL DEFAULT '0',
  `get_last_action_time` int(10) unsigned DEFAULT NULL,
  `post_last_action_time` int(10) unsigned DEFAULT NULL,
  `get_banned_until` int(10) unsigned DEFAULT NULL,
  `post_banned_until` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_last_activity` (`last_activity`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_get_banned_until` (`get_banned_until`),
  KEY `idx_post_banned_until` (`post_banned_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (_binary '1ff273ca45e4705788dbb3bb6dcebbc196329ec95d41d8f606822b8f7652e756',1,_binary '178.176.78.180',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',1762087376,_binary '{\"lang\":\"ru\",\"HTTP_REFERER\":\"legend-world.online\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\",\"account_update_times\":{\"856\":{\"axee\":1761595764}}}','2025-10-26 18:49:33',0,0,NULL,NULL,NULL,NULL),(_binary '263313fe97440dfed9e6b150c771b351e1b114bdcc2de4f57f8349d32422ac5c',NULL,_binary '47.106.137.69',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',1763053108,_binary '[]','2025-11-13 16:58:28',0,0,NULL,NULL,NULL,NULL),(_binary '299a271db32bfdf801cd9892e0a324829c41b57f4be3d926edeffe8f8dc4c8f0',NULL,_binary '45.149.173.209',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',1763053132,_binary '{\"lang\":\"en\"}','2025-11-13 16:58:42',0,0,NULL,NULL,NULL,NULL),(_binary '3f004f061222a3a5c11a9251e932369a12bdf2bdf3b989d2690b3414cf7f07d4',1,_binary '176.212.100.233',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',1763052522,_binary '{\"HTTP_REFERER\":\"top100arena\",\"lang\":\"ru\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\"}','2025-10-25 17:20:11',0,0,NULL,NULL,NULL,NULL),(_binary '7450f129dab21af377c6a1d23de87dcec0109221da51653423afc630d6388663',NULL,_binary '34.244.56.210',_binary 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/97.0.4691.0 Safari/537.36',1763053153,_binary '[]','2025-11-13 16:59:13',0,0,NULL,NULL,NULL,NULL),(_binary '99e53b5af3e5957b2efa146524cf8a3fe0e05a2e33d88ba73184926603e1cb5d',1,_binary '178.176.77.144',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',1760993168,_binary '{\"HTTP_REFERER\":\"legend-world.online\",\"lang\":\"ru\",\"account_prefix\":\"R\",\"finger\":\"{\\\"webgl\\\":{\\\"commonImageHash\\\":\\\"3a4ed1c6378f68583893dd719f84f6c9\\\"},\\\"audio\\\":{\\\"sampleHash\\\":1168.9068228197468},\\\"system\\\":{\\\"platform\\\":\\\"Win32\\\"},\\\"locales\\\":{\\\"timezone\\\":\\\"Europe\\/Moscow\\\"},\\\"hardware\\\":{\\\"videocard\\\":{\\\"renderer\\\":\\\"WebKit WebGL\\\"}}}\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\",\"account_update_times\":{\"856\":[]}}','2025-10-20 20:13:52',0,0,NULL,NULL,NULL,NULL),(_binary '9e5dc77140943b113cb7f1fd0bfce25cbf7520e82d0c17e2813f4ea792471f40',4,_binary '188.130.177.41',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',1762649331,_binary '{\"HTTP_REFERER\":\"legend-world.online\",\"lang\":null,\"id\":\"4\",\"email\":\"TG:@Cannabytes\",\"password\":\"TELEGRAM\",\"oauth2\":true}','2025-11-09 00:47:58',0,0,NULL,NULL,NULL,NULL),(_binary 'b1373b5baf3ca762e467ecf55b90e2dfcbe71e3306a3f62676419eddd7cc4f59',NULL,_binary '3.93.247.16',_binary 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/86.0.4240.0 Safari/537.36',1763053153,_binary '[]','2025-11-13 16:59:13',0,0,NULL,NULL,NULL,NULL),(_binary 'b5bed2552364f4984ef4bc3d7f90ada3c96b6d2597d1cd60d0669ec6fbab4aca',9,_binary '101.56.223.127',_binary 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',1762930437,_binary '{\"HTTP_REFERER\":\"legend-world.online\",\"lang\":null,\"id\":\"9\",\"email\":\"yuliias@smart-glocal.com\",\"password\":\"apace479\"}','2025-11-12 06:50:18',0,0,NULL,NULL,NULL,NULL),(_binary 'b9ef373684752676ea88274270b80bd9fcdfdbfe8b6a5ba7f183a57d2d51b72a',1,_binary '185.121.233.68',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',1763053096,_binary '{\"lang\":\"ru\",\"HTTP_REFERER\":\"l2topru\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\"}','2025-11-10 17:13:12',0,0,NULL,NULL,NULL,NULL),(_binary 'c56c7d6b227000bfb541ba6baa775a1d13011cc67f8c1df6fd0a9ec6fdad12d5',1,_binary '185.121.233.68',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',1762091800,_binary '{\"HTTP_REFERER\":\"legend-world.online\",\"lang\":\"ru\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\"}','2025-11-02 13:55:45',0,0,NULL,NULL,NULL,NULL),(_binary 'cfcd4d1f3daba12e9ac00f9077865a014603c0a12d5e009792e0f6ed181523ed',1,_binary '31.173.82.95',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',1762710978,_binary '{\"lang\":\"ru\",\"HTTP_REFERER\":\"legend-world.online\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\",\"send_to_game_1\":1762537174}','2025-11-07 17:17:13',0,0,NULL,NULL,NULL,NULL),(_binary 'd2526e65b008be41e4839d37fc31ac6a2bd4833f17b95b3965bb668d60031e76',1,_binary '77.40.56.46',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',1761465607,_binary '{\"lang\":\"ru\",\"HTTP_REFERER\":\"legend-world.online\",\"account_prefix\":\"G\",\"finger\":\"{\\\"webgl\\\":{\\\"commonImageHash\\\":\\\"3a4ed1c6378f68583893dd719f84f6c9\\\"},\\\"audio\\\":{\\\"sampleHash\\\":1168.9068228197468},\\\"system\\\":{\\\"platform\\\":\\\"Win32\\\"},\\\"locales\\\":{\\\"timezone\\\":\\\"Europe\\/Moscow\\\"},\\\"hardware\\\":{\\\"videocard\\\":{\\\"renderer\\\":\\\"WebKit WebGL\\\"}}}\",\"id\":1,\"email\":\"xxfosters@gmail.com\",\"password\":\"5DQ-L3B-XLC-89u\",\"account_update_times\":{\"856\":{\"axee\":1761424374}},\"warehouse_to_game_1\":1761413587,\"send_to_game_1\":1761413689}','2025-10-08 17:19:22',0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `setting` longtext COLLATE utf8mb4_unicode_ci,
  `serverId` int(11) DEFAULT NULL,
  `dateUpdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (3,_binary '__config_logo__',_binary '{\"favicon\":{\"1024\":\"/uploads/logo/favicon_1024.png\",\"512\":\"/uploads/logo/favicon_512.png\",\"256\":\"/uploads/logo/favicon_256.png\",\"128\":\"/uploads/logo/favicon_128.png\",\"64\":\"/uploads/logo/favicon_64.png\",\"48\":\"/uploads/logo/favicon_48.png\",\"32\":\"/uploads/logo/favicon_32.png\",\"16\":\"/uploads/logo/favicon_16.png\"},\"logo\":\"/uploads/logo/logo.webp?v=68fce5086833f\"}',0,'2025-10-25 17:56:08'),(15,_binary '__config_background__',_binary '{\"login\":\"uploads/background/login.webp?v=68e96b521a0c7\",\"registration\":\"uploads/background/registration.webp?v=68e96b6b5d84b\",\"forget\":\"uploads/background/forget.webp?v=68e96b724cd36\"}',0,'2025-10-10 23:24:18'),(25,_binary '__config_email__',_binary '{\"emailHost\":\"smtp.spaceweb.ru\",\"emailPort\":\"465\",\"emailUsername\":\"support@legend-world.online\",\"emailPassword\":\"6FKNCHQyMX#R6ZEM\",\"emailFrom\":\"support@legend-world.online\",\"emailSMTPAuth\":\"true\",\"emailProtocol\":\"ssl\"}',0,'2025-10-12 12:50:33'),(40,_binary '__config_template__',_binary '{\"template\":\"l2lw\"}',0,'2025-10-24 23:07:06'),(44,_binary '__config_menu__',_binary '{\"neonEffects\":\"true\",\"menuStyle\":\"red\"}',0,'2025-10-25 18:13:43'),(54,_binary '__config_enabled__',_binary '{\"enable_news\":\"true\",\"enable_shop\":\"false\",\"enable_balance\":\"true\",\"enable_statistic\":\"true\",\"enable_support\":\"true\",\"enable_send_balance_game\":\"true\",\"enable_bonus_code\":\"true\",\"enable_stream\":\"false\",\"enable_emulation\":\"false\"}',0,'2025-10-25 18:45:55'),(55,_binary '__config_lang__',_binary '{\"detectBrowserLang\":\"true\",\"allow\":[\"ru\",\"en\",\"ua\"],\"default\":\"ru\"}',0,'2025-10-25 18:46:36'),(56,_binary '__config_registration__',_binary '{\"enablePrefix\":\"false\",\"massRegistration\":\"false\",\"enableLoadFileRegistration\":\"false\",\"phraseRegistrationDownloadFile\":\"text_registration_account\",\"minimumNumberOfCharactersRegistrationAccount\":\"4\",\"maximumNumberOfCharactersRegistrationAccount\":\"16\",\"prefixType\":\"prefix\",\"prefixCharacters\":\"1-3\"}',0,'2025-10-25 20:31:10'),(66,_binary '__config_cheating__',_binary '{\"isEnableOnlineCheaters\":\"false\",\"minOnlineShow\":\"0\",\"maxOnlineShow\":\"0\",\"cheatingDetails\":{\"1\":[{\"time\":\"00:00\",\"multiplier\":\"1.3\"},{\"time\":\"00:30\",\"multiplier\":\"1.34\"},{\"time\":\"01:00\",\"multiplier\":\"1.35\"},{\"time\":\"01:30\",\"multiplier\":\"1.41\"},{\"time\":\"02:00\",\"multiplier\":\"1.5\"},{\"time\":\"02:30\",\"multiplier\":\"1.6\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}],\"20\":[{\"time\":\"00:00\",\"multiplier\":\"1.4\"},{\"time\":\"00:30\",\"multiplier\":\"1.47\"},{\"time\":\"01:00\",\"multiplier\":\"1.55\"},{\"time\":\"01:30\",\"multiplier\":\"1.57\"},{\"time\":\"02:00\",\"multiplier\":\"1.59\"},{\"time\":\"02:30\",\"multiplier\":\"1.66\"},{\"time\":\"03:00\",\"multiplier\":\"1.7\"},{\"time\":\"03:30\",\"multiplier\":\"1.8\"},{\"time\":\"04:00\",\"multiplier\":\"1.9\"},{\"time\":\"04:30\",\"multiplier\":\"2\"},{\"time\":\"05:00\",\"multiplier\":\"2.1\"}]}}',0,'2025-10-26 22:01:13'),(72,_binary '__PLUGIN__sphere_forum',_binary '{\"showMainPage\":true,\"addToMenu\":true}',0,'2025-10-26 23:25:58'),(74,_binary '__config_palette__',_binary '{\"nav-layout\":\"vertical\",\"theme-mode\":\"light\",\"header-styles\":\"light\",\"menu-styles\":\"light\",\"toggled\":\"detached-close\",\"style\":\"--primary-rgb: 244, 176, 74;\",\"styleFile\":\"styles.css\"}',0,'2025-10-26 23:28:19'),(76,_binary '__PLUGIN__',_binary '[]',0,'2025-11-02 10:05:26'),(77,_binary '__config_other__',_binary '{\"saveOpenPassword\":\"false\",\"isL2Cursor\":\"false\",\"isExchangeRates\":\"false\",\"autoUpdate\":\"true\",\"enableTechnicalWork\":\"false\",\"allTitlePage\":\"Legend-World\",\"undefined\":\"\",\"onlinemul\":\"1\",\"isAuthShow\":\"false\",\"isShow404error\":\"true\",\"isAllowDeleteAccount\":\"true\",\"linkLogo\":\"\\/\",\"isEnableMenuPageLink\":\"true\",\"linkMainPage\":\"\\/\",\"linkPrivacyPolicy\":\"https:\\/\\/legend-world.online\\/page\\/1\",\"linkUserAgreement\":\"https:\\/\\/legend-world.online\\/page\\/1\",\"linkServerRules\":\"\",\"max_account\":\"10\",\"timeoutSaveStatistic\":\"300\",\"timezone\":\"Europe\\/Kyiv\",\"messageTechnicalWork\":\"\",\"keywords\":\"\",\"contactAdmin\":\"\",\"balanceNotice\":\"\",\"analyticsHead\":\"\",\"analyticsBody\":\"\"}',0,'2025-11-02 10:09:26'),(81,_binary '__config_forum__',_binary '{\"enabled\":\"false\",\"showForumSphereMainPage\":\"false\",\"engine\":\"sphere\",\"sort\":\"messages\",\"elements\":\"20\"}',0,'2025-11-02 14:19:33'),(82,_binary '__config_notice__',_binary '{\"noticeLang\":\"ru\",\"telegramTokenApi\":\"8205403688:AAEv84lShH9dhGgTViw-Wck5gAt5oY0P54c\",\"telegramChatID\":\"-1002975743624\",\"isTechnicalSupport\":\"true\",\"isDonationCrediting\":\"true\",\"isTranslationGame\":\"true\",\"isRegistrationUser\":\"true\",\"isRegistrationAccount\":\"true\",\"isForgetPassword\":\"false\",\"isChangeAccountPassword\":\"false\",\"isChangeUserPassword\":\"false\",\"isSyncAccount\":\"false\",\"isAddStream\":\"false\",\"isUseWheel\":\"false\",\"isUseBonusCode\":\"true\",\"isBuyStartPack\":\"false\",\"isBuyShop\":\"false\",\"isSendWarehouseToGame\":\"false\",\"isSendPlayerToVillage\":\"false\"}',0,'2025-11-02 14:27:44'),(88,_binary '__config_donate__',_binary '{\"serverId\":\"856\",\"paySystemDefault\":\"freekassa\",\"minSummaPaySphereCoin\":\"1\",\"maxSummaPaySphereCoin\":\"300\",\"defaultSummaPaySphereCoin\":\"1\",\"sphereCoinCost\":\"1\",\"ratioUSD\":\"1\",\"ratioEUR\":\"1.09\",\"ratioUAH\":\"40.54\",\"ratioRUB\":\"90.44\",\"enableCumulativeDiscountSystem\":\"true\",\"table_CumulativeDiscountSystem\":[{\"coin\":\"50\",\"percent\":\"5\"},{\"coin\":\"100\",\"percent\":\"10\"},{\"coin\":\"150\",\"percent\":\"15\"},{\"coin\":\"200\",\"percent\":\"20\"},{\"coin\":\"250\",\"percent\":\"25\"},{\"coin\":\"300\",\"percent\":\"30\"}],\"enableOneTimeBonus\":\"true\",\"table_EnableOneTimeBonus\":[{\"coin\":\"20\",\"percent\":\"10\"},{\"coin\":\"50\",\"percent\":\"15\"},{\"coin\":\"100\",\"percent\":\"20\"}],\"enableSystemDiscountsOnItemPurchases\":\"false\",\"enableIncludeOneTimeDiscountsOnThePurchaseOfItemsByQuantity\":\"false\",\"rewardForDonatingItems\":\"false\",\"donateSystems\":{\"0\":{\"freekassa\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"merchant_id\":\"9bcadca7ecae97357dbcbff0d0e7357e\",\"secret_key_1\":\"u2wA5,DXMaP}PVz\",\"secret_key_2\":\"Qv6cnr1sZfVcCXf\"},\"description\":\"freekassa\",\"sort\":\"0\",\"country\":[\"ru\",\"ua\",\"world\",\"crypto\"],\"customName\":\"freekassa\",\"currency\":\"RUB\"}},\"2\":{\"primepayments\":{\"enable\":\"true\",\"forAdmin\":\"true\",\"inputs\":{\"project_id\":\"\",\"secret_1\":\"\",\"secret_2\":\"\"},\"description\":\"primepayments\",\"sort\":\"1\",\"country\":[\"ru\",\"ua\",\"world\"],\"customName\":\"primepayments\",\"currency\":\"RUB\"}},\"4\":{\"paypal\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"clientId\":\"\",\"secretKey\":\"\",\"webhookId\":\"\"},\"description\":\"paypal\",\"sort\":\"10\",\"country\":[\"world\"],\"customName\":\"paypal\",\"currency\":\"USD\"}},\"6\":{\"stripe\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"secret_key\":\"\",\"webhook_secret_key\":\"\"},\"description\":\"stripe\",\"sort\":\"11\",\"country\":[\"world\"],\"customName\":\"stripe\",\"currency\":\"USD\"}},\"8\":{\"unitpay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"publicKey\":\"\",\"secretKey\":\"\"},\"description\":\"unitpay\",\"sort\":\"12\",\"country\":[\"ru\"],\"customName\":\"unitpay\",\"currency\":\"RUB\"}},\"10\":{\"wata\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"access_token\":\"\"},\"description\":\"wata\",\"sort\":\"13\",\"country\":[\"ru\"],\"customName\":\"wata\",\"currency\":\"RUB\"}},\"12\":{\"yookassa\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yookassa\",\"sort\":\"14\",\"country\":[\"ru\"],\"customName\":\"yookassa\",\"currency\":\"RUB\"}},\"14\":{\"yoomoney\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"yoomoney\",\"sort\":\"15\",\"country\":[\"ru\"],\"customName\":\"yoomoney\",\"currency\":\"RUB\"}},\"16\":{\"enot\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"enot\",\"sort\":\"3\",\"country\":[\"ru\"],\"customName\":\"enot\",\"currency\":\"RUB\"}},\"18\":{\"betatransfer\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"public_api_key\":\"\",\"secret_api_key\":\"\"},\"description\":\"betatransfer\",\"sort\":\"2\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"betatransfer\",\"currency\":\"UAH\"}},\"20\":{\"aaiopay\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"merchant_id\":\"\",\"secret_key_1\":\"\",\"secret_key_2\":\"\"},\"description\":\"aaiopay\",\"sort\":\"4\",\"country\":[\"ru\",\"ua\",\"crypto\"],\"customName\":\"aaiopay\",\"currency\":\"RUB\"}},\"22\":{\"cardlink\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"cardlink\",\"sort\":\"5\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"cardlink\",\"currency\":\"RUB\"}},\"24\":{\"cryptocloud\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"apiKey\":\"\",\"shopId\":\"\",\"secretKey\":\"\"},\"description\":\"cryptocloud\",\"sort\":\"6\",\"country\":[\"world\"],\"customName\":\"cryptocloud\",\"currency\":\"USD\"}},\"26\":{\"morune\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"secret_key\":\"\",\"secret_key_additional\":\"\"},\"description\":\"morune\",\"sort\":\"7\",\"country\":[\"ru\"],\"customName\":\"morune\",\"currency\":\"RUB\"}},\"28\":{\"pally\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"pally\",\"sort\":\"8\",\"country\":[\"ru\",\"ua\"],\"customName\":\"pally\",\"currency\":\"RUB\"}},\"30\":{\"palych\":{\"enable\":\"false\",\"forAdmin\":\"false\",\"inputs\":{\"shop_id\":\"\",\"api_key\":\"\"},\"description\":\"palych\",\"sort\":\"9\",\"country\":[\"ru\",\"crypto\"],\"customName\":\"palych\",\"currency\":\"RUB\"}}},\"item_id_to_game_transfer\":\"4037\",\"count_items_to_game_transfer\":\"1\",\"donate_item_to_game_transfer\":\"1\"}',856,'2025-11-13 00:50:33');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `shop_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shop_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serverId` int(11) DEFAULT NULL,
  `items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `category` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `shop_items` WRITE;
/*!40000 ALTER TABLE `shop_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `shop_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `startpacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `startpacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `name` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `items` varchar(6000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `startpacks` WRITE;
/*!40000 ALTER TABLE `startpacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `startpacks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `statistic_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statistic_online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `loginserver` int(11) DEFAULT NULL,
  `gameserver` int(11) DEFAULT NULL,
  `count_online_player` mediumtext,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `statistic_online` WRITE;
/*!40000 ALTER TABLE `statistic_online` DISABLE KEYS */;
INSERT INTO `statistic_online` VALUES (1,856,NULL,NULL,_binary '{\"2025-09-30\":{\"19:00\":0,\"20:00\":0,\"21:00\":0},\"2025-10-01\":{\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0},\"2025-10-02\":{\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0},\"2025-10-05\":{\"18:00\":0,\"19:00\":4,\"20:00\":1,\"21:00\":2,\"22:00\":1},\"2025-10-07\":{\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0},\"2025-10-08\":{\"13:00\":0},\"2025-10-25\":{\"20:00\":2,\"21:00\":2,\"22:00\":0,\"23:00\":0},\"2025-10-26\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":1,\"22:00\":6,\"23:00\":0},\"2025-10-27\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":2},\"2025-10-28\":{\"00:00\":2,\"01:00\":1,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":2,\"21:00\":3,\"22:00\":4,\"23:00\":0},\"2025-10-29\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":1,\"19:00\":1,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":2},\"2025-10-30\":{\"00:00\":0,\"01:00\":0,\"03:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":1},\"2025-10-31\":{\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"09:00\":0,\"10:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-01\":{\"00:00\":0,\"01:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-02\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-03\":{\"00:00\":0,\"01:00\":2,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"21:00\":0,\"22:00\":0},\"2025-11-04\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":1,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-05\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-06\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-07\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-08\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-09\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-10\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":1},\"2025-11-11\":{\"00:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-12\":{\"00:00\":0,\"01:00\":0,\"02:00\":0,\"03:00\":0,\"04:00\":0,\"05:00\":0,\"06:00\":0,\"07:00\":0,\"08:00\":0,\"09:00\":0,\"10:00\":0,\"11:00\":0,\"12:00\":0,\"13:00\":0,\"14:00\":0,\"15:00\":0,\"16:00\":0,\"17:00\":0,\"18:00\":0,\"19:00\":0,\"20:00\":0,\"21:00\":0,\"22:00\":0,\"23:00\":0},\"2025-11-13\":{\"00:00\":0}}','2025-11-13 01:07:18');
/*!40000 ALTER TABLE `statistic_online` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `streams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `streams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `channel` varchar(600) DEFAULT NULL,
  `channel_id` varchar(255) DEFAULT NULL,
  `data` varchar(3000) DEFAULT NULL,
  `confirmed` int(11) DEFAULT NULL,
  `is_live` int(11) DEFAULT NULL,
  `auto_check_date` datetime DEFAULT NULL,
  `dateUpdate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `dateCreate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `streams` WRITE;
/*!40000 ALTER TABLE `streams` DISABLE KEYS */;
/*!40000 ALTER TABLE `streams` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message` mediumtext,
  `screens` varchar(1000) NOT NULL,
  `date_update` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_message` WRITE;
/*!40000 ALTER TABLE `support_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_message` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_message_screen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_message_screen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_message_screen` WRITE;
/*!40000 ALTER TABLE `support_message_screen` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_message_screen` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_read_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_read_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `read_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_read_topics` WRITE;
/*!40000 ALTER TABLE `support_read_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_read_topics` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_thread` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL COMMENT 'создатель вопроса',
  `last_user_id` int(11) DEFAULT NULL COMMENT 'ID последнего ответа',
  `last_message_id` int(11) DEFAULT NULL COMMENT 'ID последнего сообщения',
  `private` int(11) NOT NULL DEFAULT '0',
  `is_close` int(11) NOT NULL DEFAULT '0',
  `date_update` datetime DEFAULT NULL,
  `date_create` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_thread` WRITE;
/*!40000 ALTER TABLE `support_thread` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_thread` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `support_thread_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_thread_name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread_name` varchar(600) DEFAULT NULL,
  `moderators` varchar(1000) DEFAULT NULL,
  `thread_count` int(11) NOT NULL DEFAULT '0',
  `weight` int(11) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `support_thread_name` WRITE;
/*!40000 ALTER TABLE `support_thread_name` DISABLE KEYS */;
INSERT INTO `support_thread_name` VALUES (1,_binary 'account',NULL,0,0),(2,_binary 'Client, crash',NULL,0,0),(3,_binary 'Server problems',NULL,0,0),(4,_binary 'Payment problems',NULL,0,0),(5,_binary 'Complaints about players',NULL,0,0),(6,_binary 'other',NULL,0,0);
/*!40000 ALTER TABLE `support_thread_name` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `telegram_auth_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_auth_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telegram_id` bigint(20) NOT NULL,
  `telegram_username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telegram_auth_sessions_token_unique` (`token`),
  KEY `telegram_auth_sessions_token_index` (`token`),
  KEY `telegram_auth_sessions_telegram_id_index` (`telegram_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `telegram_auth_sessions` WRITE;
/*!40000 ALTER TABLE `telegram_auth_sessions` DISABLE KEYS */;
INSERT INTO `telegram_auth_sessions` VALUES (2,_binary 'ALozZA',509612868,_binary 'sergey_chelentano',_binary 'Sergius',_binary 'Vyazemsky',_binary 'ru','2025-11-11 19:47:02','2025-11-11 19:45:02','2025-11-11 19:45:02');
/*!40000 ALTER TABLE `telegram_auth_sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `last_message_id` int(11) DEFAULT NULL,
  `last_user_id` int(11) DEFAULT NULL,
  `is_closed` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tickets_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `message_id` int(11) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tickets_file` WRITE;
/*!40000 ALTER TABLE `tickets_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets_file` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tickets_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `is_file` int(11) DEFAULT '0',
  `message` varchar(4000) DEFAULT NULL,
  `read` int(11) DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tickets_message` WRITE;
/*!40000 ALTER TABLE `tickets_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets_message` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_auth_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ip` varchar(60) DEFAULT NULL,
  `country` varchar(60) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `browser` varchar(600) DEFAULT NULL,
  `fingerprint` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `os` varchar(100) DEFAULT NULL,
  `device` varchar(100) DEFAULT NULL,
  `user_agent` varchar(600) DEFAULT NULL,
  `signature` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_auth_log` WRITE;
/*!40000 ALTER TABLE `user_auth_log` DISABLE KEYS */;
INSERT INTO `user_auth_log` VALUES (1,1,_binary '77.40.56.46',_binary 'Russia',_binary 'Yoshkar-Ola',_binary 'Chrome',_binary '207560e9e602a574','2025-10-09 20:54:43',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',_binary '{\"webgl\":{\"commonImageHash\":\"3a4ed1c6378f68583893dd719f84f6c9\"},\"audio\":{\"sampleHash\":1168.9068228197468},\"system\":{\"platform\":\"Win32\"},\"locales\":{\"timezone\":\"Europe/Moscow\"},\"hardware\":{\"videocard\":{\"renderer\":\"WebKit WebGL\"}}}'),(2,1,_binary '178.176.77.144',_binary 'Russia',_binary 'Moscow',_binary 'Chrome',_binary '207560e9e602a574','2025-10-20 23:19:13',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',_binary '{\"webgl\":{\"commonImageHash\":\"3a4ed1c6378f68583893dd719f84f6c9\"},\"audio\":{\"sampleHash\":1168.9068228197468},\"system\":{\"platform\":\"Win32\"},\"locales\":{\"timezone\":\"Europe/Moscow\"},\"hardware\":{\"videocard\":{\"renderer\":\"WebKit WebGL\"}}}'),(3,2,_binary '176.212.100.233',_binary 'Russia',_binary 'Bryansk',_binary 'Chrome',NULL,'2025-10-25 20:29:57',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',_binary 'GOOGLE'),(4,2,_binary '176.212.100.233',_binary 'Russia',_binary 'Bryansk',_binary 'Chrome',NULL,'2025-10-25 20:29:58',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',_binary 'GOOGLE'),(5,1,_binary '178.176.78.180',_binary 'Russia',_binary 'Moscow',_binary 'Chrome',NULL,'2025-10-26 21:59:45',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',_binary 'GOOGLE'),(6,1,_binary '185.121.233.68',_binary 'The Netherlands',_binary 'Amsterdam',_binary 'Chrome',NULL,'2025-11-02 16:56:18',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',_binary 'GOOGLE'),(7,1,_binary '31.173.82.18',_binary 'Russia',_binary 'Moscow',_binary 'Chrome',NULL,'2025-11-07 20:27:18',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',_binary 'GOOGLE'),(8,4,_binary '188.130.177.41',_binary 'Ukraine',_binary 'Odesa',_binary 'Firefox',NULL,'2025-11-09 03:48:10',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0',_binary 'TELEGRAM'),(9,1,_binary '5.165.91.56',_binary 'Russia',_binary 'Bryansk',_binary 'Chrome',NULL,'2025-11-10 11:16:08',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',_binary 'GOOGLE'),(10,1,_binary '185.121.233.68',_binary 'The Netherlands',_binary 'Amsterdam',_binary 'Chrome',NULL,'2025-11-10 20:15:17',_binary 'Windows 10',_binary 'desktop',_binary 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 YaBrowser/25.8.0.0 Safari/537.36',_binary 'GOOGLE'),(11,9,_binary '101.56.223.127',_binary 'Italy',_binary 'Spinea',_binary 'Chrome',NULL,'2025-11-12 09:53:20',_binary 'macOS',_binary 'desktop',_binary 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',_binary 'GOOGLE');
/*!40000 ALTER TABLE `user_auth_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_variables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `var` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `val` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `date_create` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_update` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_variables` WRITE;
/*!40000 ALTER TABLE `user_variables` DISABLE KEYS */;
INSERT INTO `user_variables` VALUES (141,0,4,_binary 'account_update_times',_binary '{\"856\":{\"_last_check\":1762649311}}','2025-11-09 03:48:31','2025-11-09 03:48:31'),(163,0,2,_binary 'account_update_times',_binary '{\"856\":{\"_last_check\":1762762534}}','2025-11-10 11:15:35','2025-11-10 11:15:35'),(222,0,9,_binary 'HTTP_REFERER',_binary 'legend-world.online','2025-11-12 09:53:20','2025-11-12 09:53:20'),(225,0,9,_binary 'account_update_times',_binary '{\"856\":{\"_last_check\":1762930437}}','2025-11-12 09:53:57','2025-11-12 09:53:57'),(249,0,1,_binary 'account_update_times',_binary '{\"856\":{\"axee\":1763052724,\"_last_check\":1762977747}}','2025-11-13 19:52:04','2025-11-13 19:52:04');
/*!40000 ALTER TABLE `user_variables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(400) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `access_level` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `donate_point` float DEFAULT '0',
  `avatar` varchar(62) COLLATE utf8mb4_unicode_ci DEFAULT 'none.jpeg',
  `avatar_background` varchar(62) COLLATE utf8mb4_unicode_ci DEFAULT 'none.jpeg',
  `timezone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `server_id` int(11) DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_last_activity` (`last_activity`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,_binary 'xxfosters@gmail.com',_binary '$2y$12$rJzk2Hh9nzcvqsHCvkA1qeBiMqwXjxC04K3bp9ibhNgBe975r1DkO',_binary 'Admin',NULL,_binary '77.40.56.46','2025-10-08 17:41:34','2025-11-13 16:58:16',_binary 'admin',99,_binary '538507b672154448fc30.jpeg?c=c603',_binary 'none.jpeg',_binary 'Europe/Moscow',_binary 'RU',_binary 'Moscow',856,_binary 'ru','2025-11-13 16:58:16'),(2,_binary 'somsin.dmitrii@gmail.com',_binary 'GOOGLE',_binary 'Dmitrii Somsin',NULL,_binary '176.212.100.233','2025-10-25 17:29:57','2025-11-10 08:13:47',_binary 'user',100,_binary 'none.jpeg',_binary 'none.jpeg',_binary 'Europe/Moscow',_binary 'RU',_binary 'Bryansk',856,NULL,'2025-11-10 08:13:47'),(4,_binary 'TG:@Cannabytes',_binary 'TELEGRAM',_binary 'Cannabytes',NULL,_binary '188.130.177.41','2025-11-09 00:48:10','2025-11-09 00:48:10',_binary 'user',0,_binary 'none.jpeg',_binary 'none.jpeg',_binary 'Europe/Kyiv',_binary 'UA',_binary 'Odesa',856,NULL,'2025-11-09 03:48:10'),(9,_binary 'yuliias@smart-glocal.com',_binary '$2y$12$ZR1TqdF6gQWh15dKqnoIs.MimrsdgEZ/HPlMkYgrzQQhwQRTSHmui',_binary 'user-c911',NULL,_binary '101.56.223.127','2025-11-12 06:53:14','2025-11-12 06:53:14',_binary 'user',0,_binary 'none.jpeg',_binary 'none.jpeg',_binary 'Europe/Rome',_binary 'IT',_binary 'Vicenza',856,NULL,'2025-11-12 09:53:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_password_forget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_password_forget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_password_forget` WRITE;
/*!40000 ALTER TABLE `users_password_forget` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_password_forget` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_permission` (
  `user_id` int(11) NOT NULL,
  `ban_page` int(11) DEFAULT '0',
  `ban_ticket` int(11) DEFAULT '0',
  `ban_gallery` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users_permission` WRITE;
/*!40000 ALTER TABLE `users_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_permission` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warehouse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `enchant` int(11) DEFAULT '0',
  `phrase` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issued` int(11) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warehouse` WRITE;
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;
UNLOCK TABLES;
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

